(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"970x250_200k_atlas_1", frames: [[0,735,850,719],[852,735,850,719],[1704,735,850,478],[0,377,3827,356],[0,0,4074,375],[2908,735,350,263],[2556,735,350,350]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Image = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Image_1_1 = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Image_3 = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.S_C6_1psd = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.S_C6_2psd = function() {
	this.initialize(ss["970x250_200k_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// phoneLight
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.349)","rgba(255,255,255,0.749)","rgba(255,255,255,0.494)","rgba(255,255,255,0)"],[0.153,0.725,0.824,0.824,0.824],101.1,-48.9,-132.2,63.9).s().p("A+wUsMAAAgpXMA9gAAAMAAAApXg");
	this.shape.setTransform(196.85,132.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0,393.7,264.9), null);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF2A0C").ss(2).p("AJfAAQAAD7iyCyQiyCyj7AAQj6AAiyiyQiyiyAAj7QAAj6CyiyQCyiyD6AAQD7AACyCyQCyCyAAD6g");
	this.shape.setTransform(60.675,60.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgRA4QAWgFASgJQAWgKAMgKIAGAJQgeAXgtAMgAgxBCIAAhFIgJAOIgFgPQAFgIAJgTQAGgOAFgSIALACQgEASgGAQIAABdgAgbAsIAAhWIAKAAIAABWgAgKAhQANgEAPgHQAQgHALgJIAHAJQgNAKgOAGQgQAJgNADgAgJAMQAZgIATgLIAFAIQgUANgYAIgAgPgIQASgGALgGQgGgEgGgIIgLALIgHgJQAIgHAHgJIAKgTIAMAEIgEAJIAmAAIAAAKQgIANgLAJQANAGAPADIgEALQgVgFgOgIQgRAKgSAFgAAJgpIgBAAQAIAJAJAHQAKgIAGgJIggAAg");
	this.shape_1.setTransform(102.75,79.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgEBCIAAhLIgHAKIgHgMQAIgLAGgOQAFgOACgOIANACQgCALgEAKIAUAAIgHgUIAMgCIAIAWIASAAIAAAMIgWAAIAAARIAVAAIAAALIgVAAIAAAQIAVAAIAAALIgVAAIAAASIAYAAIAAAMIg4AAIAAAKgAAHAsIATAAIAAgSIgTAAgAAHAPIATAAIAAgQIgTAAgAAHgMIATAAIAAgRIgTAAgAg+A8IAHgjIAJABIgHAkgAgmA5IgDgfIAJAAIADAhIgJAAgAgbAZIAIgCIAKAfIgJACgAgUAQIgkAEIgDgLIASgXIgRABIgEgLQAOgUALgVIAKAFQgMAWgJAOIAOgBIANgTIAJAGQgNAUgVAbIAVgDIgFgMIAJgDIALAcIgJADg");
	this.shape_2.setTransform(88.9,79.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgEBCIAAgbIgZAAIAAAVIgMAAIAAgXQgFADgLAEIgGgKQAVgIAMgKIgeAAIAAgKIAnAAIAEgGIgeAAIAAgmIAUAAIAAgIIghAAIAAgJIAhAAIAAgJIANAAIAAAJIAdAAIAAgJIAOAAIAAAJIAgAAIAAAJIggAAIAAAIIATAAIAAAmIgyAAIgEAGIBEAAIAAAKIgeAAQAOAMARADIgDAMIgRgGIAAAJQABAGgCACQgBADgEACQgCABgIAAIgMAAIgBgJIAKAAQAFAAABgBQABgCAAgEIAAgFIgYAAIAAAbgAAHATIAAAKIAXAAQgIgFgHgIIgdAAQgGAIgJAFIAZAAIAAgKgAghgJIBEAAIAAgHIhEAAgAghgXIBEAAIAAgGIhEAAgAgOgmIAdAAIAAgIIgdAAg");
	this.shape_3.setTransform(75.05,79.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAsA6IhnACIgBgLIA2gBIAAgMIgpAAIAAgeIApAAIAAgHIAMAAIAAAHIApAAIAAAeIgIAAIAWAWIgJAIgAAGAwIAcgBIgEgEIAIgHIggAAgAAGAaIAcAAIAAgLIgcAAgAgiAaIAcAAIAAgLIgcAAgAAsAEIAAgJIhZAAIAAAJIgNAAIAAgUIAHAAIgFgHQAHgDAHgFQAFgEACgFQACgFAAgJIAAgLIAMAAIAAAMQAAAGgBAGIAUAQIgGAJIgSgPQgHAJgNAGIAzAAIApAAIgUgQQgDAEgFAFQgIAFgFACIgFgKQAJgEADgCQAEgFADgEQACgEAAgJIAAgLIALAAIAAAMQAAAHgBAFIAXASIgGAHIAJAAIAAAUgAAjgrIAOgQIAIAHIgPAPgAgSgrIAKgQIAIAEIAGgEIALAQIgIAGIgDgGIgGgLIgLARgAg4g1IAIgGIAMAPIgIAHg");
	this.shape_4.setTransform(61.325,79.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag1A2QAJgKAEgIQAEgGABgMQACgKAAgSIAAg0IBXAAIAABmQAAAIgCAEQgCAEgEACQgFABgIAAIgUAAIgDgOIAaAAIADgCIABgXIg9AAQgDANgDAJQgFAJgIALgAgUAHIA8AAIAAgUIg8AAgAgUgaIA8AAIAAgWIg8AAg");
	this.shape_5.setTransform(46.625,79.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAvBBIAAgHIg4AAIAAAHIgMAAIAAh7IBRAAIAAB7gAgJAuIA4AAIAAhbIg4AAgAguBBIAAhEIgIAOIgFgQQAOgYAIgiIANACIgJAfIAABfgAAAAiIAAglIANAAIAAgOIgSAAIAAgMIASAAIAAgNIALAAIAAANIATAAIAAAMIgTAAIAAAOIAOAAIAAAlgAAKAXIARAAIAAgQIgRAAg");
	this.shape_6.setTransform(33.225,79.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#040000").s().p("AgeAzQgMgNAAgVQAAgqArgmIAYAAQgfAZgMAdQALgJALABQARgBALALQALALAAARQAAATgMAMQgNAMgSAAQgSAAgMgNgAgWAIIgBAKQAAANAHAJQAGAIAKAAQALAAAGgHQAHgIAAgLQAAgLgGgHQgHgGgLAAQgKAAgMAKg");
	this.shape_7.setTransform(17.075,78.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AArA+IAAgGIhVAAIAAAGIgOAAIAAh7IBxAAIAAB7gAgqAsIBVAAIAAhdIhVAAgAgbAfIAAgmIAWAAIAAgNIgfAAIAAgMIAfAAIAAgNIALAAIAAANIAfAAIAAAMIgfAAIAAANIAXAAIAAAmgAgPAVIAgAAIAAgSIggAAg");
	this.shape_8.setTransform(81.975,60.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AALBAIAAgnQgIAKgGAIQgIAGgNAIIgHgLQAOgIAIgHQAJgJAGgIIggAAIAAgMIAlAAIAAgNIgcAAIAAgvIBHAAIAAAvIgdAAIAAANIAlAAIAAAMIghAAQAGAJAJAHQAJAIAMAHIgHAMQgJgGgLgJQgHgIgGgJIAAAngAgEgYIAtAAIAAgVIgtAAgAguBAIAAhFQgEAHgIAKIgGgNQAIgLAHgSQAIgPAEgSIANADQgDAPgHAPIAABeg");
	this.shape_9.setTransform(68.1,60.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAABCIAAgeIg9AAIAAgNIATAAIAAglIAqAAIAAgXIgdAAQgKAPgPAQIgHgNQAMgMAGgKQAIgMAFgMIAOAEIgGALIBRAAIAAANIgsAAIAAAXIAoAAIAAAMIgoAAIAAAZIAvAAIAAANIgvAAIAAAegAgdAXIAdAAIAAgZIgdAAg");
	this.shape_10.setTransform(54.325,60.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgmBAIAAgMQA4gzAAgYQAAgKgHgHQgGgGgJgBQgPABgQAMIAAgSQASgLARAAQAQAAALALQAKAKAAAQQAAAbgyAwIA0AAIAAAPg");
	this.shape_11.setTransform(37.575,59.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CE0000").s().p("AgsBWQgCgDAAgEQABgEADgCQA0giARhZIhCgVQgJgCADgJQACgJAJADIBRAZIgBAHIgOA5QgXA9gpAbIgFABQgFAAgCgEg");
	this.shape_12.setTransform(65.695,30.3716);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CE0000").s().p("AgDCLQhQgXgjhlQgLgfgGglQgEgXAAgLIAAgJICLgrICMArIgBAJIgDAiQgGAlgLAfQgkBlhQAXIgDABgAhyhOQAGA2ATAsQAfBMA6ATQA7gTAghMQASgsAGg2Ihzgjg");
	this.shape_13.setTransform(61.05,30.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-1,-1,123.4,123.4), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF2A0C").s().p("AhQByIAAhbIgTAYIgKgVQAfgmANgjIgoAAIAAgVIAhAAIgQglIARgIIASAkIgSAJIAcAAIAAAVQgFAOgNAYIAAABIAcAaIgMAQIgQgQIAABggAgrBsIAAgRIAsAAIgKgOIAJgHIgZAAIAAgqIB3AAIAAAqIgWAAIAHAEIgLARIAqAAIAAARgAAZBYIgFADIAXAAIAPgVIgvAAgAgEA3IBOAAIAAgMIhOAAgAgiAQIAAgQICMAAIAAAQgAgegMIAAhQIAjAAIAAgTIATAAIAAATIAVAAIAAgTIATAAIAAATIAkAAIAABQgAA9gcIAVAAIAAgRIgVAAgAAYgcIAVAAIAAgRIgVAAgAgNgcIAUAAIAAgRIgUAAgAA9g8IAVAAIAAgPIgVAAgAAYg8IAVAAIAAgPIgVAAgAgNg8IAUAAIAAgPIgUAAg");
	this.shape.setTransform(259.2,11.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF2A0C").s().p("AhuBgIAZgWQAMgMAGgJQgSgPgPgLQAKgmAFgiIgXAAIAAgXIAaAAQADgPACgeIAWACIgEArIAtAAIAAAWQgEAdgGAbQgEAVgJASIAhAbIgQATIgdgaQgPAVgdAYgAhLARIAUAQQAHgRADgQQAFgTADgaIgaAAQgGAlgGAZgAAEBuIgFgYIAXAAQAKAAADgDQADgDAAgIIAAg7IgyAAIAAgXIAyAAIAAgcIAmgkIhOAAIAAgYIBsAAIAAAYIgsAsIAAAUIAyAAIAAAXIgyAAIAABDQAAARgHAHQgHAGgTAAg");
	this.shape_1.setTransform(235.65,11.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF2A0C").s().p("AgyBIQgUgbAAgtQAAgrAUgcQATgcAfAAQAgAAATAcQAUAcAAArQAAAtgUAbQgTAcggAAQgfAAgTgcgAgeg2QgLAVAAAhQAAAiALAVQAMAVASAAQATAAALgVQAMgVAAgiQAAghgMgVQgLgVgTAAQgSAAgMAVg");
	this.shape_2.setTransform(208.15,11.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF2A0C").s().p("AgyBIQgUgbAAgtQAAgrAUgcQATgcAfAAQAfAAAVAcQATAcAAArQAAAtgTAbQgVAcgfAAQgfAAgTgcgAgeg2QgMAVAAAhQAAAiAMAVQAMAVASAAQATAAAMgVQAMgVAAgiQAAghgMgVQgMgVgTAAQgSAAgMAVg");
	this.shape_3.setTransform(193.7,11.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF2A0C").s().p("AgyBIQgUgbAAgtQAAgrAUgcQATgcAfAAQAfAAAVAcQATAcAAArQAAAtgTAbQgVAcgfAAQgfAAgTgcgAgeg2QgMAVAAAhQAAAiAMAVQAMAVASAAQATAAAMgVQALgVAAgiQAAghgLgVQgMgVgTAAQgSAAgMAVg");
	this.shape_4.setTransform(179.3,11.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF2A0C").s().p("AgYAgIAXg+IAaAAIgZA+g");
	this.shape_5.setTransform(168.325,21.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF2A0C").s().p("AgqBhIBHioIhZAAIAAgZIB5AAIAAARIhJCwg");
	this.shape_6.setTransform(159.075,11.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF2A0C").s().p("AAKBhIAAihIgwAbIAAgaIA5ghIAUAAIAADBg");
	this.shape_7.setTransform(143.825,11.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF2A0C").s().p("AgHBsIAAgiQgUgBgQgJIAAgSQATANAVAAQAMAAAJgHQAJgHAAgLQAAgQgjgOQglgMAAgaQAAgPAKgKQALgLARgDIAAgiIAPAAIAAAiQAQABAQAHIAAASQgTgLgRAAQgNAAgJAGQgIAHAAALQAAAPAkANQAkAMAAAbQAAAQgKALQgLALgRADIAAAig");
	this.shape_8.setTransform(131.625,13.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF2A0C").s().p("AhUBxIAAh3QgJAOgKAPIgIgdQAMgTALgbQALgbAIghIAYAFQgJAfgIAWIAACngAg0BrIAAgUIAUAAIAAiMIAyAAIAAgTIg7AAIAAgVIA7AAIAAgTIAXAAIAAATIBCAAIAAAVIhCAAIAAATIA0AAIAACMIATAAIAAAUgAgJBXIBPAAIAAgTIhPAAgAgJAzIBPAAIAAgRIhPAAgAgJAQIBPAAIAAgQIhPAAgAgJgQIBPAAIAAgSIhPAAg");
	this.shape_9.setTransform(105.125,11.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF2A0C").s().p("AAqBeIAFgRQAaAHAlANIgHASgAg0BgQAPgDASgGIAfgLIAHASIggALIgiAKgAhUBwIAAh3QgJARgHALIgJgaQALgTALgdQAKgbAJgiIAVAFQgIAfgIAXIAACngAghBKIAAhWIB/AAIAABWgAgMA6IBVAAIAAgKIhVAAgAgMAjIBVAAIAAgKIhVAAgAgMALIBVAAIAAgKIhVAAgAgqgYIAAgwIAqAAIAAgOIgsAAIAAgQICYAAIAAAQIgwAAIAAAOIArAAIAAAwgAA8gnIAXAAIAAgRIgXAAgAATgnIAWAAIAAgRIgWAAgAgXgnIAXAAIAAgRIgXAAgAAThIIAWAAIAAgOIgWAAg");
	this.shape_10.setTransform(81.7,11.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF2A0C").s().p("AhhByIAAhrIDCAAIAABOQAAALgCAGQgDAGgHADQgGACgMAAIgcAAIgEgUIAXAAQAKAAADgDQADgCAAgJIAAg3IiTAAIAABagAgwBaIAAgyIBiAAIAAAygAgbBJIA2AAIAAgRIg2AAgAhKgIIAAgxICVAAIAAAxgAg0gYIBoAAIAAgQIhoAAgAhshIIAAgSIBiAAIgIgSIAYgFIALAXIBcAAIAAASg");
	this.shape_11.setTransform(58.25,11.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF2A0C").s().p("AgZBuIAAgWIhSALIgCgUIAUgCIAAhTIgUAAIAAgTIDaAAIAAATIhxAAIAABJIAOgCIABASIgPADIAAAYgAhEBLIArgGIAAgNIgrAAgAhEApIArAAIAAgRIgrAAgAhEAJIArAAIAAgPIgrAAgAAABaQAUgIARgMQgHgIgIgMIgOgaIAAgSIBXAAIAAATQgKAZgSATQARALAaAJIgJAUQgcgKgVgQQgSAPgZALgAA0A4QAMgMAIgUIgqAAQAIARAOAPgAhRglIAAhIIChAAIAABIgAg6g2IBzAAIAAgMIhzAAgAg6hRIBzAAIAAgLIhzAAg");
	this.shape_12.setTransform(34.725,12.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF2A0C").s().p("AhqBmQAPgYAKgXIAQAJQgMAcgNAWgABOBxIAAgLIhAAAIAAALIgUAAIAAhkIBpAAIAABkgAAOBUIBAAAIAAgSIhAAAgAAOAyIBAAAIAAgSIhAAAgAg6BBIAQgKIAaAtIgRAKgAhgA0IAAiYIBEAAIAACYgAhNAfIAfAAIAAgYIgfAAgAhNgMIAfAAIAAgXIgfAAgAhNg3IAfAAIAAgYIgfAAgAgOgBIAAhVIAbAAIgMgVIAUgFIANAaIAWAAQAJgPAFgMIAUAFIgMAWIAdAAIAABVgAA3gTIAiAAIAAgxIgiAAgAADgTIAjAAIAAgxIgjAAgAA5ghIARgdIAOAHIgSAfgAAFg2IAOgIIAQAeIgOAIg");
	this.shape_13.setTransform(10.725,11.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF2A0C").s().p("AggBDIgDgPIAaAAQABAAAAgBQABAAAAAAQAAAAABgBQAAAAAAgBIABgXIg+AAIAAgPIA+AAIAAgUIgzAAIAAgOIAzAAIAAgXIg0ADIgBgPQAWAAAigDIA6gFIACAOIgwAFIAAAYIAwAAIAAAOIgwAAIAAAUIA6AAIAAAPIg6AAIAAAWQAAAHgCAFQgCADgFADQgDABgIAAg");
	this.shape_14.setTransform(159.375,59.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF2A0C").s().p("AAWAfQgPgUgGgXQgOAqgsAlIgLgNQA3gsAIg4IgEgEQgCgBgHAAIgUAAIAAgPIAaAAQAJAAAFADQAFAEABAJQADAiAPAYQAOAbAdATIgLAOQgXgSgNgTg");
	this.shape_15.setTransform(143.925,59.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF2A0C").s().p("Ag/A8QAZgMAOgPQARgQAKgUIALAFQgKASgLAOIAaAYIgKALIgZgZQgQAPgWANgAAdBFIgDgPIAPAAQAGAAADgCQACgDAAgEIAAhwIANAAIAAB1QAAAKgEAFQgEAEgMAAgAhAAdQALgGAJgIQAGgFAKgKIgcACIgDgNQANgMAJgQIgYAAIAAgOIAiAAIgFgPIAPgDIAGASIAaAAIAAAOIgkAAIgTAbIAWgCIALgSIALAFQgNAZgNAOQgOAPgUANgAAXAmIAAhaIANAAIAABag");
	this.shape_16.setTransform(128.225,59.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FF2A0C").s().p("AAMBDIAAiDIAzAAIAABaQAAAKgEAEQgFAEgJAAIgNAAIgDgPIALAAQAGAAACgCQABgBAAgGIAAhFIgXAAIAAB0gAg+AwIAEgEIABgFIAAhpIA5AAIAABIIgsAAIAAAiIAYgLIgHgNIAMgGIAVAoIgLAHIgIgQIgqATgAgsgGIAfAAIAAgRIgfAAgAgsgkIAfAAIAAgRIgfAAg");
	this.shape_17.setTransform(113.025,59.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF2A0C").p("AGyCcItkAAQhAAAguguQgtguAAhAQAAg/AtguQAuguBAAAINkAAQBAAAAuAuQAuAuAAA/QAABAguAuQguAuhAAAg");
	this.shape_18.setTransform(136.3,59.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,270.2,75.9), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgQAYQALgFAEgHQAFgHAAgKIgQAAIAAgeIAdAAIAAAeQAAAMgGALQgHALgNAGg");
	this.shape.setTransform(134.3,79.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AALBlIgDgSIAaAAIALgCQAEgBAAgCQACgEAAgGIAAhEIiUAAIAAgSICmAAQgTgIg0gUQgLAKgSAGQgSAHgeAEIgHgRQAigFAPgGQAPgFAGgLIhIAAIAAgTIBNAAIABgSIAUAAIAAASIBPAAIAAATIhSAAIgBADIBLAbIgJAPIAbAAIAAASIgbAAIAABIQABAMgDAGQgEAGgGACQgGADgOAAgAhNBMIAAg8IBiAAIAAA8gAg3A6IA3AAIAAgYIg3AAg");
	this.shape_1.setTransform(198.25,78.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhMBnIAAhtQgFAMgJALIgIgWQALgTAJgZQAIgVAJggIAUAEQgGAbgJAXIAACXgAASBlIgDgSIAVAAQAHAAAEgDQACgCAAgIIAAgJIg8AAIAaARIgLAOIgfgVIAHgKIgZAAIAAgRIBeAAIAAgPIhaAEIgBgQIA7gBIAAgPIgzAAIAAg5IAzAAIAAgMIg5AAIAAgQIA5AAIAAgSIATAAIAAASIA+AAIAAAQIg+AAIAAAMIA0AAIAAA5IgKAAIAVAdIgOAJIgGgKIgJAAIAAAPIAeAAIAAARIgeAAIAAAQQAAAIgDAGQgCAFgHADQgFACgLAAgAAkAPIAfgBIgDgFIAMgIIgoAAgAAkgLIAhAAIAAgKIghAAgAgPgLIAgAAIAAgKIggAAgAAkghIAhAAIAAgKIghAAgAgPghIAgAAIAAgKIggAAg");
	this.shape_2.setTransform(175.75,78.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhPBnIAAhkIAwAAQAGgOABgIIAWAEIgGASIBPAAIAABkIgVAAIAAgLIhrAAIAAALgAg5BLIBrAAIAAgTIhrAAgAg5AnIBrAAIAAgSIhrAAgAhcgaQAEgCABgDQACgCAAgEIAAhAIAUAAIAAAWIA3AAIAAATIg3AAIAAAbIA1gNIACASIhMAUgAAYgOQgLAAgHgGQgFgGAAgNIAAg/IAVAAIAAAeQArgPAOgHIAHASIhAAXIAAAIQAAAIADACQADACAGABIAaAAQAIgBADgCQADgDAAgIIABgSIASAFIgBAWQgBAOgHAEQgGAFgQAAg");
	this.shape_3.setTransform(153.625,78.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgjBYIAJgDIhFAKIgCgRIAfgFIAAg/IgbAAIAAgRIAbAAIAAgSIgQAAIAAgLIgLANIgFgWQARgSAQgjIAQAAIAdAnIgKAQQgMgTgOgSQgIATgNATIAtAAIAAARIgRAAIAAASIAYAAIAAARIgYAAIAAA8IAXgEIABATQASgGAGgIQAGgIAAgMIgUAAIAAhHIBkAAIAABHIgaAAIAAAWQAAAGADACQABACAFAAIAFAAQAHAAACgCQABgBABgGIAAgVIAQAEIgBAWQAAAMgGAEQgFAEgNAAIgNAAQgKAAgGgEQgFgFAAgLIAAgcIgRAAQgBAUgLAMQgMAMgaAKgAACAkIBBAAIAAgNIhBAAgAACAIIBBAAIAAgMIhBAAgAhZAqIgGgTIANgGIAOAoIgPAGgAgvA6QAGgPAGgZIANAEIgLAogAgXggIAAgQIAaAAIgDgVIgRAAIAAgQIArAAIgFgPIATgEIAHATIAuAAIAAAQIgUAAIgGAVIAgAAIAAAQgAAWgwIAaAAIAGgVIgkAAg");
	this.shape_4.setTransform(114.8,78.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhiAMIAAgXIDFAAIAAAXg");
	this.shape_5.setTransform(92.275,77.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgCBoIgFgTIAjAAQAKAAAEgDQAFgDAAgGIiAAAIAHgyIgZAAIAAgTIAbAAIAGgyIgTAVIgNgTQANgLANgRQANgRAHgOIAVAGIgHANICDAAIAAATIiPAAIgPASICMAAIgDAzIAbAAIAAATIgcAAIgBAgIAYAAIAAASIgYAAQgBANgDAGQgEAHgHACQgHADgMAAgAAWApIgHAOIAiAAIABggIg9AAgAg5A3IBDAAIgjgUIAHgMIgjAAgAAYgKIgIAOIAjAAIABggIg8AAQAaAOAGAEgAgyAEIA/AAIgjgUIAGgMIgeAAg");
	this.shape_6.setTransform(69.85,78.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#030000").s().p("AADBTQgZgaAAg3QAAg4AagZQAXgXA5AAQA4AAAYAXQAaAaAAA3QAAA4gbAaQgXAXg4AAQg6AAgXgYgAAlgvQgHAIgCANQgCAJAAATQAAATACAJQACAOAHAIQANAOAiAAQAhAAANgOQAHgIACgOQACgJAAgTQAAgTgCgJQgCgNgHgIQgNgOghAAQgiAAgNAOgAjbBmQgSgEgNgKQgTgPgDgdQgCgRAFgQQAGgPAWgMQATgKAsgBQARgBAmACQgBgTgEgFQgFgIgUgDQgQgDgTACQgaACgiAMQgCABgDgBQAAgBgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAghIABgEQAAgBAAgBQAAAAABAAQAAgBABAAQAAgBABAAQAbgKAsgCQBCgEAbAlQAOAUACApIAAAoQgCAbgJAQQgIAOgOAIQgWALgoABIgGAAQgcAAgTgEgAiuALQgoABgJAMQgDAEAAAMQABAOAMAGQAMAHAlgCQAfgBAHgNQADgIABgdQgYgEgTAAIgJABgAJpBnQAAAAgBAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAjDQAAgBAAgBQABgBAAAAQAAAAABgBQABAAAAAAIArAAQABAAABAAQAAABABAAQAAAAABABQAAABAAABIAADDQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAgAl7BnQgBAAgBAAQAAAAgBgBQAAAAgBgBQAAAAAAgBIAAjDQAAgBAAgBQABgBAAAAQABAAAAgBQABAAABAAIArAAQABAAAAAAQABABAAAAQABAAAAABQAAABAAABIAADDQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAgAnxBnIgEgCIgxhCIgzBCQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAIg4AAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBIBNhgIhNhfQgBgBAAAAQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIA4AAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAIAxBDIAzhDQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAIA3AAQABAAAAAAQABAAAAABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAgBABIhMBdIBNBiQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAgAHzBnQAAAAgBgBQgBAAAAAAQAAAAgBgBQAAgBAAAAIAAhnQAAgngDgGQgGgMgaAAQgVAAgHACQgHADgDAJIgCAMIAACGQAAAAAAABQgBABAAAAQAAAAgBAAQgBABAAAAIgrAAQgBAAgBgBQAAAAgBAAQAAAAgBgBQAAgBAAAAIAAiGIgCgMQgDgJgHgDQgHgCgVAAQgaAAgGAMQgDAGAAAnIAABnQAAAAAAABQgBABAAAAQAAAAgBAAQgBABAAAAIgrAAQgBAAgBgBQAAAAgBAAQAAAAgBgBQAAgBAAAAIAAh9QAAgZAEgNQAEgOAKgJQATgQAxAAQAmAAAXAMIAIAAQAXgMAkAAQAxAAAUASQALALADAPQADAMAAAcIAAB2QAAAAAAABQgBABAAAAQgBAAAAAAQgBABgBAAg");
	this.shape_7.setTransform(66.375,10.6849);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAKBlIAAgyIhWAAIAAgYIBch/IAfAAIAAB6IAeAAIAAAdIgeAAIAAAygAgnAWIAxAAIAAhFg");
	this.shape_8.setTransform(168.375,10.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAGBlIAAigIgxAcIAAgjIA9giIAaAAIAADJg");
	this.shape_9.setTransform(150.75,10.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgxBDIAAghQAWANAVAAQAJAAAHgEQAFgFAAgHQAAgJgggMQgjgMAAgdQAAgUAQgNQAPgMAYAAQAXAAATAIIAAAhQgTgMgUAAQgJAAgFAFQgHAEAAAGQABAIAhANQAiAMAAAeQAAAUgQANQgQANgZAAQgVAAgYgKg");
	this.shape_10.setTransform(262.4,13.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AguA3QgWgWAAghQAAghAVgWQAVgVAeAAQAdAAASAUQASAVAAAgIAAANIhjAAQABARAMAKQANALARAAQAUAAAYgOIAAAgQgaALgYAAQghAAgUgWgAgUgmQgJAJgBAQIA/AAQgBgPgIgKQgJgJgNAAQgNAAgJAJg");
	this.shape_11.setTransform(247.85,13.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgSBpIAAiTIAlAAIAACTgAgPhDQgFgGgBgKQABgJAFgGQAHgGAIAAQAJAAAHAGQAFAGAAAJQAAAKgFAGQgHAGgJAAQgIAAgHgGg");
	this.shape_12.setTransform(235.95,10.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgqBMIAAiTIAlAAIAAAOQAQgRAUgBQAIABAEABIAAAiQgGgCgHAAQgUAAgPATIAABig");
	this.shape_13.setTransform(226.925,13.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgvA3QgVgWAAghQAAgiAUgVQAVgVAfAAQAdAAASAUQASAVAAAgIgBANIhjAAQACARAMAKQANALARAAQATAAAZgOIAAAgQgaALgYAAQghAAgVgWgAgUgmQgJAJgCAQIA/AAQAAgPgJgKQgIgJgMAAQgOAAgJAJg");
	this.shape_14.setTransform(212.7,13.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag/BcIAAgkQAcASAcAAQAQAAALgIQAKgIAAgNQAAgOgPgIIghgNQgygRAAgnQAAgZAVgRQAUgQAfAAQAcAAAbALIAAAjQgagPgaAAQgQAAgKAHQgKAIAAAMQAAANAQAJIAhAMQAxARAAAoQAAAagVARQgVARgfAAQgeAAgdgNg");
	this.shape_15.setTransform(196.575,10.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgIABQAAgHAIAAQAJAAAAAGQAAAHgJAAQgIAAAAgGg");
	this.shape_16.setTransform(288.875,38.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgwAsIgagIQgIAIgPAAQgHAAgFgDQgHgEABgGQABgJAOAAQAJAAAHADQAIgTABgJQgHgBgGgCIACgFIAMADIABgBQAKgrAYABQAGAAAEAEQAFAEAAAGQAAAPgQALIgQAIQgGASgEAKIgCADIAXAHQAeAHAcABQBDAAAjgMIACAFQgxAQg5AAQgbAAgggIgAhrAhQAAAAAAABQAAAAAAAAQAAABABAAQAAAAABABQACABADAAQAFAAAHgFQgGgDgGAAQgHAAAAAEgAgzgbIgEARIALgFQALgIABgNQABgIgHAAQgHAAgGARg");
	this.shape_17.setTransform(287.6982,40.5239);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AghAPIgCgEQgNAIgOAAQgUAAAAgQQAAgIAHgGQAIgGAMAAQAPAAAAAKQAAALgVABIgEgBIAAABQgBAHAKAAQAMgCAJgGIAHgUIAQAAIgGAWQAAABAAABQAAAAAAABQABAAAAAAQABABABAAQAGAAADgGIAAgBQABgIAFgGQAIgGAKAAQAHAAADACIgCAHQgCgEgEAAQgFAAgDAHQgCAFAAADQAAAHAGABQAHAAAGgIIAAgBQABgGAFgHQAIgHAKAAQAIAAACAEIABgCIAPAAIgGAVQAAABAAABQAAABABAAQAAABABAAQAAAAABAAQACAAAEgDIABAGQgHAGgIAAQgFAAgDgDIgCgDQgFAGgJAAQgGAAgFgEIgCgEQgKAIgLABQgHgBgDgDIgEgEQgJAIgLAAQgGAAgDgEgAAwgFQgCAFAAAEQAAAHAEAAQAJAAACgSQAAgFgFAAQgFAAgDAHgAg/gGIgBAGQANABAAgKQAAgBAAAAQAAgBgBAAQAAgBgBAAQgBAAAAAAIgBAAQgFAAgDAGg");
	this.shape_18.setTransform(290.7,41.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FF2A0C").s().p("AhfBgQgognAAg5QAAg3AogoQAngoA4AAQA4AAAoAoQAoAoAAA3QAAA5goAnQgoAog4AAQg3AAgogog");
	this.shape_19.setTransform(288.075,41.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#030000").s().p("AAPAiIAAgfIgdAAIAAAfIgKAAIAAhDIAKAAIAAAcIAdAAIAAgcIAKAAIAABDg");
	this.shape_20.setTransform(265.275,41.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#030000").s().p("AgEAiIAAg6IgSAAIAAgJIAtAAIAAAJIgSAAIAAA6g");
	this.shape_21.setTransform(258.5,41.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#030000").s().p("AgEAiIAAhDIAJAAIAABDg");
	this.shape_22.setTransform(253.725,41.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#030000").s().p("AAMAiIgMgvIgLAvIgMAAIgRhDIAKAAIANA2IANg2IAIAAIAOA2IANg2IAJAAIgRBDg");
	this.shape_23.setTransform(247.2,41.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#030000").s().p("AgZAiIAAhDIATAAQAMAAAIAGQAMAKAAARQAAARgKAJQgJAIgTAAgAgPAZIAGAAIAJgBQALgCADgNIABgJQAAgTgOgEQgFgBgHAAIgEAAg");
	this.shape_24.setTransform(235.25,41.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#030000").s().p("AgUAiIAAhDIAoAAIAAAJIgdAAIAAATIAaAAIAAAIIgaAAIAAAWIAeAAIAAAJg");
	this.shape_25.setTransform(228.45,41.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#030000").s().p("AAMAiIgOgcIgLAAIAAAcIgKAAIAAhDIAaABQALACAEAHQADADAAAHQAAAGgDAFQgDADgDABIgEADIAQAdgAgNgCIAKAAQANAAAAgLQAAgHgFgCIgGgCIgIAAIgEAAg");
	this.shape_26.setTransform(222.025,41.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#030000").s().p("AgUAiIAAhDIAoAAIAAAJIgdAAIAAATIAaAAIAAAIIgaAAIAAAWIAeAAIAAAJg");
	this.shape_27.setTransform(215.4,41.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#030000").s().p("AgTAiIAAhDIAmAAIAAAJIgcAAIAAATIAbAAIAAAIIgbAAIAAAWIAdAAIAAAJg");
	this.shape_28.setTransform(209.15,41.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#030000").s().p("AAPAiIgegzIAAAzIgKAAIAAhDIALAAIAeAzIAAgzIAKAAIAABDg");
	this.shape_29.setTransform(201.95,41.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#030000").s().p("AgEAiIAAhDIAJAAIAABDg");
	this.shape_30.setTransform(196.225,41.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#030000").s().p("AgSAaQgIgJAAgRQAAgVAOgJQAIgEAGAAQAPAAAHAMIACAKIgJAAQgDgKgGgCIgGgBQgHAAgFAHQgFAHAAALQAAAaASAAQAJAAAGgEIAAgOIgOAAIAAgIIAXAAIAAAcIgGADQgJAEgJAAQgMAAgJgJg");
	this.shape_31.setTransform(190.6,41.35);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#030000").s().p("AAOAiIgcgzIAAAzIgKAAIAAhDIALAAIAcAzIAAgzIAKAAIAABDg");
	this.shape_32.setTransform(183.1,41.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#030000").s().p("AgUAiIAAhDIAoAAIAAAJIgdAAIAAATIAaAAIAAAIIgaAAIAAAWIAeAAIAAAJg");
	this.shape_33.setTransform(176.35,41.375);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#030000").s().p("AgNAgQgPgJAAgXQAAgUANgJQAIgFAHAAQALAAAIAHQAKAKAAARQAAAWgNAJQgHAEgJAAQgHAAgGgDgAgHgXQgHAEgCAKIgBAJQAAAKADAGQACAEACACQAFAEAFAAQAJAAAGgJQADgGAAgLQAAgOgHgHQgDgEgIAAQgEAAgDACg");
	this.shape_34.setTransform(165.5,41.35);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#030000").s().p("AgJAgQgQgJAAgWQAAgUAMgKQAHgFAIAAQAPAAAHAMQACAFAAAFIgJAAIgCgGQgEgHgJAAQgFAAgFAFQgGAIgBANQAAAOAIAHQAEAEAFAAQAGAAADgDQAGgEAAgJIAKAAQgBAKgEAGQgHAJgMAAQgGAAgGgDg");
	this.shape_35.setTransform(158.2,41.35);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#030000").s().p("AgNAEIAAgHIAaAAIAAAHg");
	this.shape_36.setTransform(171.15,42.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,301.7,88.8), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhMSATzMAAAgnlMCYlAAAMAAAAnlg");
	this.shape.setTransform(488.3,126.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,976.6,253.4), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnRJkIEP0AIDKApIAciCIEOA5IgaCEIC6AoIkLUGg");
	mask.setTransform(88.725,94.55);

	// Layer_3
	this.instance = new lib.S_C6_2psd();
	this.instance.setTransform(31.65,0,0.4355,0.4355,11.9687);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(42.1,18.8,93.30000000000001,151.6), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmsGtQiyixAAj8QAAj6CyiyQCyiyD6AAQD7AACyCyQCyCyAAD6QAAD8iyCxQiyCyj7AAQj6AAiyiyg");
	mask_1.setTransform(98.525,79.4);

	// Layer_3
	this.instance_1 = new lib.S_C6_1psd();
	this.instance_1.setTransform(0,0,0.5925,0.5925);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(37.9,18.7,121.29999999999998,121.39999999999999), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgIAJQgDgEAAgFQAAgEADgEQAEgDAEAAQAFAAAEADQADAEAAAEQAAAFgDAEQgEADgFAAQgEAAgEgDgAgFgFQgCADAAACQAAADACADQADACACAAQADAAADgCQACgDAAgDQAAgCgCgDQgDgCgDAAQgCAAgDACg");
	this.shape.setTransform(308.475,7.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAeAaIAAgdQAAgIgDgFQgEgEgGAAQgEAAgDACQgEADgBADQgCAEAAAFIAAAdIgFAAIAAgdQAAgIgDgFQgEgEgGAAQgEAAgDACQgEADgBADQgCAEAAAFIAAAdIgGAAIAAgyIAGAAIAAAJIAAAAQADgEAEgDQAEgDAEAAQAGAAAEADQADADACAGQACgFAFgEQAFgDAFAAQAIAAAFAGQAFAFAAAKIAAAeg");
	this.shape_1.setTransform(301.825,5.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgLAXQgFgDgDgGQgDgGAAgIQAAgHADgGQADgGAFgEQAGgDAFAAQAHAAAFADQAFAEADAGQADAGAAAHQAAAIgDAGQgDAGgFADQgFAEgHAAQgGAAgFgEgAgIgSQgEADgCAFQgCAEAAAGQAAAHACAEQACAFAEADQAFADADAAQAEAAAFgDQAEgDACgFQACgEAAgHQAAgGgCgEQgCgFgEgDQgFgDgEAAQgDAAgFADg");
	this.shape_2.setTransform(294.775,5.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJAYQgFgEgDgGQgDgGAAgIQAAgHADgGQADgHAFgCQAGgEAFAAQAGAAAFADQAFADADAFIgFADQgBgEgFgCQgEgDgEAAQgEAAgEADQgDACgDAGQgCAEgBAGQABAHACAEQACAFAEADQAEADAEAAQAFAAADgCQAEgCACgFIAFADQgDAFgFADQgGADgFAAQgFAAgGgDg");
	this.shape_3.setTransform(289.5,5.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_4.setTransform(285.825,7.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgCAlIAAgyIAFAAIAAAygAgCgdIgBgDIABgDIACgBQABAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQgBAAAAABQAAAAgBAAQAAAAgBAAIgCgBg");
	this.shape_5.setTransform(283.6,4.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAeAaIAAgdQAAgIgDgFQgEgEgGAAQgEAAgDACQgEADgBADQgCAEAAAFIAAAdIgFAAIAAgdQAAgIgDgFQgEgEgFAAQgFAAgDACQgDACgCAEQgCAEAAAFIAAAdIgGAAIAAgyIAGAAIAAAJIAAAAQADgEAEgDQAEgDAEAAQAGAAAEADQADADACAGQACgFAFgEQAFgDAGAAQAHAAAFAGQAFAFAAAKIAAAeg");
	this.shape_6.setTransform(278.275,5.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgYAqIAGgOIAEgNIABgoIAaAAIgBgSIAEAAIABASIAZAAIAAAEIgYAAQACAVADAOQAFgLAFgPIAEABIgFARIgIAOIAEAMIAEAEIACABQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBIADgSIAEACIgCAMQgBAGgBADQgDADgCgBQgFAAgEgIIgEgJQgGAJgKAIIgDgCQAKgKAHgKQgEgRgBgYIgXAAIAAAQIAQAAIgBAaQAAAEgCADQgCACgEAAIgFAAIgBgFIAFAAIADAAIABgCIACgEIABgUIgNAAIgBARIgDAOQgBAGgGAIgAgqAXIALgDIAAggIgJAAIAAgFIAJAAIAAgYIAEAAIAAAYIAJAAIAAAFIgJAAIAAAeIAJgDIABAFIgYAIgAAXgnIACgDIALALIgDACg");
	this.shape_7.setTransform(265.75,4.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgiArIAAg3IAUAAIgEgPIgXAAIAAgEIApAAIgEgKIAEgBIAFALIAlAAIAAAEIgWAAIgFAPIAUAAIAAAtQAAAFgCADQgDACgGAAIgLAAIgBgEIAKAAQAFAAACgCQABgCAAgDIAAgoIg7AAIAAAzgAgJgMIATAAIAFgPIgcAAgAgPAhIAAgXIAfAAIAAAXgAgLAdIAXAAIAAgPIgXAAgAAGgCIADgCIATAPIgDADgAgbALIAKgIIAJgHIADACIgTAQg");
	this.shape_8.setTransform(256.075,4.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgCAsIAAgpQgFAIgKAKQgKAKgMAGIgCgFQAYgOANgTIgjAAIAAgFIAlAAIAAglIAEAAIAAAlIAmAAIAAAFIgkAAQAMARAaAQIgCAFQgYgOgOgUIAAApgAANgQIASgVIADADIgSAVgAgighIAEgEIASAVIgEADg");
	this.shape_9.setTransform(246.375,4.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgUAqIgCgFIASAAQABgBAAAAQABAAAAgBQAAAAAAAAQABgBAAAAIABgGIAAhFIAEAAIAABGQAAAGgCACQgBADgBABIgIABgAgqAaQAHgMAEgNIAIgYIAGABQgDALgGAPIgLAYgAAQgWIAEgCIAXAyIgFACg");
	this.shape_10.setTransform(236.65,4.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgJArIgBgFIAYAAIADgCIACgFIADgLIgoAAIADgMQgLAGgNAGIgCgFQAYgJARgOIgoAAIAAgEIAfAAIAAgNIgWAAIAAgFIAWAAIAAgMIAGAAIAAAMIATAAIAAAFIgTAAIAAANIAIAAQAPgNAIgOIAFADQgJAMgMAMIAeAAIAAAEIgjAAIgNAKIAqAAIAAAEIgtAAIgCAKIAmAAIgCARQgCAGgDACQgCACgJAAg");
	this.shape_11.setTransform(226.95,4.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AglAoQAbgEAMgEQAOgEARgIIACAEQgLAFgUAHIgoAJgAggAbQAOgCAPgFQAJgDAOgGIACADIgYAKQgMAEgRADgAgdAPQAYgGANgHIACADQgIAFgJADIgVAFgAARADQgIgDgJgGIgRAJQgIAEgOAEIgCgEIAWgHQAJgDAIgGIgiACIgBgEQAHgDAJgKIAEACQgJAIgEADIAYgBIgHgGIACgDIALAKQAIgFAGgJIAEADIgLALIAWgBIgGgGIACgDIAPANIgDADIgEgDIgcABQAHAFAJACQAHAEAOADIgCAEIgXgIgAAZgaIg3ACIgBgEIAOgHIANgJIAEACQgKAIgLAGIApgBIgIgFIgFgCIADgEIAZAPIgCAEg");
	this.shape_12.setTransform(217.35,4.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgkAsIAAggIAXAAIAAAaIgTAAIAAAGgAggAhIAPAAIAAgRIgPAAgAgDAqIAAgqIAnAAIAAAhQAAAFgDACQgBACgGAAIgKAAIgBgEIAJAAIAFgBIABgBIABgEIAAgEIgeAAIAAAOgAABAYIAeAAIAAgIIgeAAgAABAMIAeAAIAAgIIgeAAgAgmADIAAgDIAaAAIAAADgAgIgGIAAgEIAVAAIAAgIIgRAAIAAgEIARAAIAAgHIgTAAIAAgEIATAAIAAgKIAFAAIAAAKIAVAAIAAAEIgVAAIAAAHIATAAIAAAEIgTAAIAAAIIAYAAIAAAEgAgmgKIAAgEIAaAAIAAAEgAgpgYIAAgFIAQAAIgFgNIAFgBIADAOIAOAAIAAAFg");
	this.shape_13.setTransform(207.65,4.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgcArIAAhVIAFAAIAAAOIAKAKIgCAEIgIgIIAABBgAgJArIAAgqIAtAAIAAAgQAAAFgCADQgDABgFAAIgJAAIgBgDIAIAAIAFgBIACgCIAAgDIAAgFIgjAAIAAAPgAgEAYIAjAAIAAgIIgjAAgAgEAMIAjAAIAAgIIgjAAgAgqAGIAFggIAFAAIgGAggAgPgGIAAgEIAZAAIAAgIIgTAAIAAgEIATAAIAAgIIgWAAIAAgDIAWAAIAAgJIAFAAIAAAJIAZAAIAAADIgZAAIAAAIIAXAAIAAAEIgXAAIAAAIIAcAAIAAAEg");
	this.shape_14.setTransform(197.875,4.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAOAsIAAgXIgVAAIAAgFIAVAAIAAgQIgRAAIAAgEIARAAIAAgRIgSAAIAAgEIAYAAIAKgRIAEABIgJAQIAPAAIAAAEIgVAAIAAARIATAAIAAAEIgTAAIAAAQIAXAAIAAAFIgXAAIAAAXgAgkArIAAgfIAZAAIAAAZIgUAAIAAAGgAgfAhIAQAAIAAgQIgQAAgAgkADIAAgDIAaAAIAAADgAglgJIAAgFIAbAAIAAAFgAgpgXIAAgFIAQAAIgEgOIAEgBIAGAPIAMAAIAAAFgAAAgoIAEgCIAJANIgEACg");
	this.shape_15.setTransform(188.25,4.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgEAHQAEgCAAgCQABgCAAgCIgDAAIAAgIIAHAAIAAAIQAAAHgHAEg");
	this.shape_16.setTransform(176.075,8.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgjApIAAhQIBIAAIAABDIgBAHQgBABAAAAQgBABAAAAQgBABAAAAQAAAAgBABIgIABIgKAAIgBgFIAKAAIAGgBQAAAAAAAAQABAAAAAAQAAgBAAAAQABgBAAAAIAAgFIAAg+Ig+AAIAABMgAgQAYIAAgcIAiAAIAAAcgAgMATIAZAAIAAgTIgZAAgAgXgRIAAgEIAvAAIAAAEg");
	this.shape_17.setTransform(168.85,4.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgCAoIAAg4QgOATgWARIgDgFQAQgMALgLQAKgLAIgPIgqAAIAAgFIBOAAIAAAFIgfAAIgGALIAAA/gAAHgJIAEgEIAfAbIgEAEg");
	this.shape_18.setTransform(159.2,4.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgJAoIAIgOIACgNQACgIAAgMIAAgcIASgDQAKgBAGgEIACAGIgPAEIgRADIAAAVIAjAAIAAAFIgNAAIAAAvIgFAAIAAgvIgRAAQAAAKgBAJQgBAGgDAIQgDAJgEAGgAgpApIAFgNIADgNIAAgzQAUgDAKgDIABAFQgJADgRADIAAAOIAVAAIAAAcIgWAAQAAAJgCAIIgGAQgAgcAHIARAAIAAgTIgRAAg");
	this.shape_19.setTransform(149.475,4.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgYAsIAAgvIgPAOIgDgEQARgOALgSIgZAAIAAgFIAbAAIAGgNIAFABIgFAMIAxAAIAAAFIgzAAIgIAMIAvAAIAAAuQAAAFgCACQgDACgGAAIgMAAIgBgEIAMAAIAEgBIADgBIAAgEIAAgIIgsAAIAAAUgAgSAUIAsAAIAAgNIgsAAgAgSADIAsAAIAAgLIgsAAg");
	this.shape_20.setTransform(139.8,4.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgiAoIAAg4IAaAAIAGgSIgmAAIAAgFIBRAAIAAAFIgnAAIgEASIAmAAIAAAtIgBAHIgEADIgOAAIgBgEIAMgBIACgCIABgEIAAgoIgSAAIAAAvIgFAAIAAgvIgQAAIAAAvIgFAAIAAgvIgRAAIAAA0g");
	this.shape_21.setTransform(130.125,4.725);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgpApIAAgEIAoAAIAAgPIgeAAIAAgEIAeAAIAAgIIAEAAIAAAIIAdAAIAAAEIgdAAIAAAPIAnAAIAAAEgAgnAJQAFgEAEgFQACgFABgFIgNAAIAAgFIANAAIAAgRIgKAAIAAgEIAsAAIAAAEIgKAAIAAARIAMAAIAAAFIgMAAIAAASIgEAAIAAgSIgQAAQAAAHgDAEQgCAFgHAGgAgXgPIAQAAIAAgRIgQAAgAARAJIgBgGIAIAAQAFAAABgBQABgBAAgDIAAgmIAFAAIAAAnIgBAFIgEAEIgGABgAANgCIAAggIAFAAIAAAgg");
	this.shape_22.setTransform(120.45,4.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgWApQAIgHADgHQAEgHAAgIIgLAAIAAgFIALAAIAAgIIAEAAIAAAIIAQAAIgEgyIAEAAIABAeIADAUIAMAAIgEgHIADgBIAFAIIAJAAIAAAFIgYAAIAFANIAKgLIADACQgGAJgGAEIABACIAFAGIADABIADgBIABgFIACgKIADABIgBAKQgBAGgCACQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAQgGABgFgLIgBAAIgTAKIgCgEQAKgEAJgGQgEgIgBgIIgRAAIAAAFIANAJIgCAEIgMgJQgCAHgDAEQgDAFgGAHgAgeArIAAgvQgFAQgEAHIgCgFQADgGADgJIAFgSIgKAAIAAgEIAKAAIAAgTIAEAAIAAATIAJAAIAAAEIgJAAIAAAMIAKAIIgDAEIgHgHIAAAtgAAlgFIgSACIgBgEQAEgEAHgKIgMABIgBgDIAGgIIAFgLIAEACIgFAJIgFAIIAKgBIAFgJIADABQgCAGgFAHQgFAHgEAFIAMgCIgCgHIADgBIAGAPIgEABgAAFgDIgSABIgBgDIAMgPIgMABIgBgDIAMgTIADACIgKARIAKgBIAEgJIADACQgCAEgFAIIgJANIAMgCIgDgIIADgBIAGANIAAABIgDABg");
	this.shape_23.setTransform(110.775,4.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAXAkIgPgGIABgEQAVAGALAFIgCAFIgQgGgAgpAlIAhgLIACAEIghALgAgcAXIAAgkIA5AAIAAAkgAgYATIAxAAIAAgHIgxAAgAgYAIIAxAAIAAgHIgxAAgAgYgCIAxAAIAAgHIgxAAgAgigVIAAgUIBFAAIAAAUgAANgZIARAAIAAgMIgRAAgAgHgZIAQAAIAAgMIgQAAgAgegZIASAAIAAgMIgSAAg");
	this.shape_24.setTransform(101.1,4.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgpApQAFgHAFgMIAEABQgFAMgFAIgAgFArIAAgOIgGAAIAAgEIAGAAIAAgYIASAAIAAgHIgWAAIAAgEIAMAAIAAgIIgJAAIAAgEIAJAAIAAgIIgKAAIAAgDIAKAAIAAgJIAFAAIAAAJIAPAAIAAgJIAEAAIAAAJIAOAAIAAADIgOAAIAAAIIALAAIAAAEIgLAAIAAAIIAPAAIAAAEIgZAAIAAAHIATAAIAAAYIAGAAIAAAEIgGAAIAAAEQAAAGgCABQgCACgGAAIgJAAIgBgEIAJAAIAFgBIACgEIAAgEIggAAIAAAOgAARAZIAPAAIAAgJIgPAAgAAAAZIANAAIAAgJIgNAAgAARANIAPAAIAAgIIgPAAgAAAANIANAAIAAgIIgNAAgAAIgKIAPAAIAAgIIgPAAgAAIgWIAPAAIAAgIIgPAAgAgXAXIADgBIALARIgDACgAglARIAAg1IAXAAIAAA1gAghANIAPAAIAAgMIgPAAgAghgDIAPAAIAAgMIgPAAgAghgTIAPAAIAAgMIgPAAg");
	this.shape_25.setTransform(91.4,4.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAfApIAAgHIg+AAIAAAHIgEAAIAAhRIBHAAIAABRgAgfAeIA+AAIAAhCIg+AAgAgaATQAMgGAFgHQAFgGACgJIAAgCIgXAAIAAgFIAXAAIAAgPIAEAAIAAAPIAXAAIAAAFIgXAAIgBAIIAXAWIgDAEIgVgWQgDAGgFAGQgEAEgLAHg");
	this.shape_26.setTransform(81.725,4.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAYAsIAAgFIgwAAIAAAFIgEAAIAAgfIA5AAIAAAfgAgYAkIAwAAIAAgIIgwAAgAgYAZIAwAAIAAgIIgwAAgAghAGIAAgVIBDAAIAAAVgAACADIAcAAIAAgPIgcAAgAgdADIAcAAIAAgPIgcAAgAAKAAIAKgKIACADIgKAIgAgVgHIACgDIAKAKIgDABgAASgbQgLgGgHgGQgFAGgMAHQgKAGgMAEIgCgEIAWgKQAMgHAGgGIADAAQAHAHAKAGQAIAEAPAGIgCAEQgMgFgKgGgAgRgWIAAgDIAjAAIAAADg");
	this.shape_27.setTransform(72.025,4.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgDAHQADgCAAgCQABgCAAgCIgEAAIAAgIIAIAAIAAAIQgBAHgGAEg");
	this.shape_28.setTransform(59.85,8.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgLAlIACgCIABgBIAAhJIAoAAIAAAnIgXAAIAIAQIARgMIACADQgHAGgKAGIAJAIIANAHIgDAFQgIgEgIgGQgGgFgEgHQgEgHgDgKIgJAAIAAAiIAQgIIAAAFIgUALgAgEgDIAfAAIAAgOIgfAAgAgEgVIAfAAIAAgPIgfAAgAgoApIAAhRIAZAAIAAAEIgIAYIAGALQACAEAAAGQAAAGgBACIgEAEIgIABIgEAAIgBgFIAKAAQABAAAAgBQABAAAAAAQAAgBAAAAQABgBAAAAIAAgGQAAgEgCgFIgGgKIAIgZIgPAAIAABNg");
	this.shape_29.setTransform(52.975,4.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgXAsIAAgvIgQAOIgCgEQARgPAKgRIgZAAIAAgFIAbAAIAGgNIAFABIgFAMIAwAAIAAAFIgzAAQgDAHgEAFIAvAAIAAAuQAAAFgCACQgCACgHAAIgMAAIgBgEIAMAAIAFgBIACgBIAAgEIAAgIIgtAAIAAAUgAgTAUIAtAAIAAgNIgtAAgAgTADIAtAAIAAgLIgtAAg");
	this.shape_30.setTransform(42.925,4.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgoApIAAgEIAnAAIAAgGIghAAIAAgEIAhAAIAAgGIgeAAIAAgXIA/AAIAAAXIgeAAIAAAGIAhAAIAAAEIghAAIAAAGIAnAAIAAAEgAACARIAZAAIAAgGIgZAAgAgaARIAZAAIAAgGIgZAAgAACAHIAZAAIAAgGIgZAAgAgaAHIAZAAIAAgGIgZAAgAgpgIIAAgEIBTAAIAAAEgAgfgSIAAgWIA/AAIAAAWgAgagVIA1AAIAAgGIg1AAgAgageIA1AAIAAgGIg1AAg");
	this.shape_31.setTransform(33.275,4.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAXAYQgHAKgLAKIgCgDIAKgKIAIgLQgHgMgDgSIgEAJIgDgDQAFgJADgJQAFgNABgHIAEAAIgEARIAYAAIAAAEIgGAAQAAALgEAMQgDAMgDAGQAFAKALAKIgDAEQgLgKgFgKgAAOgQIAEARIAFAOQAEgHACgIQADgJAAgMIgPAAgAgpAoQAQgDAHgEIgQgFIAFgHIgMAAIAAgFIAPAAIADgGIgNAAIAAgNIASAAIAAgHIgRAAIAAgKIgGAAIAAgDIAGAAIAAgLIARAAIAAgJIAEAAIAAAJIARAAIAAALIAFAAIAAADIgFAAIAAAKIgRAAIAAAHIARAAIAAANIgVAAIgBACIgDAEIAYAAIAAAEQgDAHgHAFIAKAFIgCAEIgNgGIgLAFIgQAEgAgbAaIAOAFQAGgEAEgGIgVAAgAgOAGIAOAAIAAgGIgOAAgAghAGIAPAAIAAgGIgPAAgAgOgNIANAAIAAgHIgNAAgAgggNIAOAAIAAgHIgOAAgAgOgXIANAAIAAgHIgNAAgAgggXIAOAAIAAgHIgOAAg");
	this.shape_32.setTransform(23.6,4.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAhApIAAgGIgXAAIAAAGIgEAAIAAgnIAgAAIAAAngAAKAeIAXAAIAAgYIgXAAgAgKApIAAgGIgVAAIAAAGIgGAAIAAgnIAgAAIAAAngAgfAeIAVAAIAAgYIgVAAgAgcgKIAAgeIA5AAIAAAegAgXgPIAvAAIAAgUIgvAAg");
	this.shape_33.setTransform(13.85,4.675);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAgAsIAAgGIgcAAIAAAGIgEAAIAAglIAlAAIAAAlgAAEAjIAcAAIAAgKIgcAAgAAEAUIAcAAIAAgKIgcAAgAgoApIAKgVIAFADIgLAUgAgVAXIAEgDIALATIgFACgAgjASIAAg2IAYAAIAAA2gAgfANIAQAAIAAgNIgQAAgAgfgDIAQAAIAAgNIgQAAgAgfgTIAQAAIAAgNIgQAAgAgDgBIAAgdIALAAIgBgDIgFgIIADgBIAIAMIAKAAIAHgNIAEACIgGALIANAAIAAAdgAAUgFIARAAIAAgVIgRAAgAAAgFIAQAAIAAgVIgQAAgAAXgKIAIgNIADACIgFAIIgDAEgAADgVIACgCIAJANIgEABg");
	this.shape_34.setTransform(4.05,4.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,309.7,9.5), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Egq+AYLMAAAgwVMBV9AAAMAAAAwVg");
	mask_2.setTransform(275.1,154.725);

	// Layer_3
	this.instance_2 = new lib.Image_2();
	this.instance_2.setTransform(0,0,0.6473,0.6473);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,550.2,309.4), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("EgkEAehMAAAg9BMBIJAAAMAAAA9Bg");
	mask_3.setTransform(230.9,195.325);

	// Layer_3
	this.instance_3 = new lib.Image_1();
	this.instance_3.setTransform(0,0,0.5433,0.5433);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0,0,461.8,390.7), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("EgliAfxMAAAg/hMBLFAAAMAAAA/hg");
	mask_4.setTransform(240.3,203.25);

	// Layer_3
	this.instance_4 = new lib.Image();
	this.instance_4.setTransform(0,0,0.5654,0.5654);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,480.6,406.5), null);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(63.3,71.65,1,1,0,0,0,90.4,90.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhCBBQAHgGAEgGQADgEACgGQABgGAAgIIAAgJIAjAAIAAAcIAQgNIADAJIgZAUIgFgIIACgCIAAgEIAAgWIgSAAIAAAEQAAAMgEAIQgDAIgLALgAAgAuQgKALgVAMIgDgJQASgLAKgJQgOgQgGgWIAAgIIA1AAIAAAIQgFAXgPAPQALALARAIIgEAKQgTgLgMgMgAAhAiQAMgOAFgSIgiAAQAFARAMAPgAgzAJIAAgIIAoAAIAAAIgAgIACIAAgKIgvAAIAAAKIgIAAIAAgSIA/AAIAAASgAACgRQAHgHACgFQACgFAAgKIAAgRIApAAIAAAcQAAAFABABIAFABIAHAAIgCAJIgJAAQgGAAgCgCQgDgDAAgHIAAgWIgXAAIAAAKQAAAKgDAHQgEAHgGAFgAg8gaIAAgIIAZAAIAAgMIgeAAIAAgIIAeAAIAAgPIAJAAIAAAPIAdAAIAAAIIgdAAIAAAMIAYAAIAAAIg");
	this.shape.setTransform(110.875,173.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAOBHIAAgeIgsAAIAAgJIAsAAIAAgMIAKAAIAAAMIArAAIAAAJIgrAAIAAAegAhABEIgCgKIANgBIADgCIABgGIAAgnIgQAHIgBgLIARgGIAAgfIgPAAIAAgKIAPAAIAAgaIAKAAIAAAaIANAAIAAAKIgNAAIAAAbIAMgFIABAJIgNAGIAAAvQAAAGgCADQgCAEgDABQgEABgGAAgAAkAPIgmADIgDgIQAIgIAOgQIgRACIgCgIQAHgJAKgPIgnAAIAAgJIApAAIgHgOIALgDIAHARIAmAAIAAAJIgpAAIgRAYIAPgCIALgPIAHAFIgRAWQgIALgJAIIAagBIgHgMIAGgEIAPAaIgHAEgAApgBIAFgGIAWAUIgGAHgAgdAMIAXgTIAGAGIgYAUgAAngQIAUgUIAGAHIgUATgAgagcIAGgGIAPAQIgGAHg");
	this.shape_1.setTransform(96.3,172.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeBAQAMgNAFgKQAGgLABgLQADgKABgaIAAgTIgPAAIAAgKIAkAAIgHgVIAJgCIAJAXIAiAAIAAAKIg4AAIgBAVIgBAEIAwAAIgDA5QAAAIgDAEQgDAEgEACQgGACgHAAIgQAAIgCgKIAYgBQAEgDABgCQACgCAAgGIACgqIglAAQAAAPgEANQgCAMgGAJQgHAMgJAKgAg/BGIAAiBIArAAIAAAKIgMAjQAGAJADAIQAEAHAAAKQAAAGgCAGQgCAFgEACQgFACgJAAIgIAAIgCgKIAIAAQAJAAACgCQADgEAAgHQAAgOgNgQIAMglIgXAAIAAB3g");
	this.shape_2.setTransform(82.05,173);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbA9QAPgHAJgIQAHgIABgMIAAgEIgNAAIAAhTIBAAAIAABTIgRAAIAAAZIABAGQACACAEAAIAEAAQAFAAACgCIABgGIAAgQIAJACIgBASIgBAIIgEAEIgJABIgJAAQgHAAgEgDQgDgCAAgIIAAgdIgOAAIAAAEQgBAQgKAJQgIAKgRAJgAABANIAuAAIAAgPIguAAgAABgLIAuAAIAAgQIguAAgAABgkIAuAAIAAgQIguAAgAhCA9QALgNAFgOQAFgOABgSIgWAAIAAgJIAWAAIABgaIgUAAIAAgKIAUAAIAAgaIAJAAIAAAaIATAAIAAAKIgTAAIAAAaIAVAAIAAAJIgVAAIgBALIAWAZIgHAIIgRgUQgCALgGALQgEAJgJAMg");
	this.shape_3.setTransform(67.125,173.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEBCIAAgVIg9AAIAAgIIA9AAIAAgNIgqAAIAAguIAqAAIAAgLIgtAAIAAgIIAtAAIAAgLIAJAAIAAALIAuAAIAAgPIhlAAIAAASIgKAAIAAgbIB5AAIAAAbIgKAAIAAAFIguAAIAAALIAqAAIAAAuIgqAAIAAANIA9AAIAAAIIg9AAIAAAVgAAFAQIAgAAIAAgMIggAAgAgkAQIAgAAIAAgMIggAAgAAFgCIAgAAIAAgMIggAAgAgkgCIAgAAIAAgMIggAAg");
	this.shape_4.setTransform(52.55,173.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgYAlQgHgGAAgLQAAgZAnAAIANAAIAAgHQgBgJgFgFQgFgFgJAAQgJAAgLAJIgGgIQANgMAOAAQAOAAAIAIQAIAIAAANIAAA2IgLAAIAAgNIgBAAQgEAHgHAEQgHAEgHAAQgMAAgHgGgAgLAJQgJADAAAIQABAGAEADQAEADAIAAQAEAAAGgCQAGgDAEgFQAEgFAAgHIAAgFIgKAAQgOAAgIAEg");
	this.shape_5.setTransform(36.75,174.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgTA2QgHgGgFgKQgFgJABgNQgBgMAFgJQAFgKAHgFQAIgFAKAAQAHAAAHAEQAHAEAEAHIABAAIAAgwIAMAAIAABzIgMAAIAAgNIgBAAQgEAIgHADQgHAEgHAAQgKAAgIgFgAgMgKQgEAEgFAGQgDAIAAAJQAAAJADAHQAEAHAFAEQAHAEAGAAQAGAAAGgEQAGgFADgGQADgHAAgJQAAgKgDgHQgEgGgFgEQgGgEgGAAQgHAAgGAEg");
	this.shape_6.setTransform(28.85,173.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSAlQgJgEgEgKQgFgKAAgNQAAgLAFgKQAEgKAJgFQAIgGAKAAQALAAAIAGQAJAFAEAKQAFAKAAALQAAANgFAKQgEAKgJAEQgIAGgLAAQgKAAgIgGgAgRgWQgHAJAAANQAAAPAHAIQAGAJALAAQAMAAAGgJQAHgIAAgPQAAgNgHgJQgHgJgLAAQgKAAgHAJg");
	this.shape_7.setTransform(20.825,174.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAfA6IAAg3Ig9AAIAAA3IgLAAIAAhzIALAAIAAAyIA9AAIAAgyIALAAIAABzg");
	this.shape_8.setTransform(11.725,173.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FF2A0C").ss(2).p("AJfAAQAAD7iyCyQixCyj8AAQj6AAiyiyQiyiyAAj7QAAj6CyiyQCyiyD6AAQD8AACxCyQCyCyAAD6g");
	this.shape_9.setTransform(60.7,85.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-27,-18.7,180.7,198.89999999999998), null);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AggA+IAEgDIABgDIAAgPQgMAGgXAKIgEgKQAWgIAKgFQAOgHALgJIg2AAIAAgJIA/AAIgHgJIAJgEIAHANIA3AAIAAAJIg7AAQAGALALAJIAbgQIAGAHIgZAPQANAJAYAFIgEAKQgWgGgRgLQgPgKgKgRIgRALIAAAWIAfgKIAAAKIgqANgAg9AAQAIgEAEgFQADgFAAgGIgRAAIAAgIIAsAAIAAgMIggAAIAAgZIAJAAIAAAQIAXAAIAAgUIAJAAIAABFIgJAAIAAgUIgSAAQAAAIgEAGQgDAGgLAGgAAAgGIAAgJIAaAAIAAgWIgdAAIAAgJIAdAAIAAgXIAJAAIAAAXIAfAAIAAAJIgfAAIAAAWIAaAAIAAAJg");
	this.shape.setTransform(97.65,147.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AApA+IhaAEIgCgKQAQgKAKgJIgoAAIAAgIIAaAAIAAguQgMAHgMAFIgEgKQASgHAKgGQAMgIAHgJIgrAAIAAgIIAyAAQAFgHAEgKIAJADIgHAOIBDAAIAAAIIgqAAQARAVAbAIIgCAJQgOgEgMgIIhFAAIAAALIBJAAIAAAIIhJAAIAAAKIBJAAIAAAHIhJAAIAAAMIBhAAIAAAIIgnAAIAeAaIgHAIgAgiA4IBCgDIgNgLIAFgFIgjAAQgNANgKAGgAgXgbIAxAAQgJgJgHgJIgRAAQgGAJgKAJg");
	this.shape_1.setTransform(83.1,147.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAJA9QARgLANgNQAMgLALgQIAGAHQgTAegiAWgAgsBCIgCgIIAKAAQAFAAADgCQACgCAAgFIAAgSIgeAAIAAgaIA/AAIAAAaIgZAAIAAAWQAAAFgBADQgBADgEABQgCABgHAAgAgvAYIAuAAIAAgMIguAAgAhDA4IALgJQAHgHAEgFIAGAFIgKANIgMALgAgJAoIAGgFIAQARIgHAGIgPgSgAANALQAMgHAMgLQAJgHAKgNIAIAFQgMAQgJAHQgNAMgKAHgAhBgCIAAgIIAmAAIgDgKIgbAAIAAgrIBBAAIAAArIgcAAIACAKIAiAAIAAAIgAgwgcIAwAAIAAgKIgwAAgAgwguIAwAAIAAgJIgwAAgAAOggQAKgGALgKQAMgMAHgIIAHAGQgMAOgIAIQgKAKgLAHg");
	this.shape_2.setTransform(68.525,148.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAzBFIAAgNIgiADIAAgIIAGAAIAAgsIgFAAIAAgHIAwAAIAAAHIgIAAIAAApIAJgBIAAAIIgJAAIAAAOgAAeAyIAVgBIAAgJIgVAAgAAeAhIAVAAIAAgKIgVAAgAAeAQIAVAAIAAgJIgVAAgAAEBFIAAgPIglAEIgBgHIAMgBIAAgrIgGAAIAAgHIAsAAIAAAHIgFAAIAAAnIAGgBIAAAIIgGABIAAAPgAgPAxIATgCIAAgIIgTAAgAgPAgIATAAIAAgJIgTAAgAgPAQIATAAIAAgJIgTAAgAg/BCIgCgJIAHAAQAEAAACgCQACgBAAgGIAAgmIgOAFIgCgKIAQgFIAAgeIgPAAIAAgKIAPAAIAAgcIAJAAIAAAcIAOAAIAAAKIgOAAIAAAbIAKgEIABAJIgLAFIAAAsQAAAGgCADQAAADgEACQgDABgFAAgAApgEIAAgGIhFACIAAgIIAPAAIAAgmIgNAAIAAgIIBZAAIAAAIIgNAAIAAAkIAQgBIABAIIgRABIAAAGgAgEgRIAtgBIAAgHIgtAAgAgEggIAtAAIAAgIIgtAAgAgEgvIAtAAIAAgHIgtAAg");
	this.shape_3.setTransform(54,148.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEBHIAAgdQgLAIgPAGQgKAFgWAGIgEgJQAUgFANgFQANgFAMgJIg4AAIAAgIIA8AAIAAgLIgvAAIAAgJIAvAAIAAgKIg4AAIAAgIIAkAAIgHgRIgjAAIAAgJIAvAAIAAgfIAKAAIAAAfIATAAIAAgfIAJAAIAAAfIAvAAIAAAJIglAAIgFARIAkAAIAAAIIg3AAIAAAKIAuAAIAAAJIguAAIAAALIA8AAIAAAIIg5AAQAVAOAmAJIgEAKQgVgGgMgFQgOgGgLgIIAAAdgAgOgMIAcAAIAGgRIgpAAgAAdgtIARgVIAHAGIgRAUgAg1g9IAHgGQAIAJAJAMIgHAGg");
	this.shape_4.setTransform(39.475,147.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAABEIgCgJIAZAAQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAAAIABgHIAAgKIg/AAIAdAQIgFAJIgfgSIAEgHIgbAAIAAgIIBdAAIAAgNIhaACIgBgIIA7gBIAAgLIgvAAIAAgmIAvAAIAAgKIg7AAIAAgIIA7AAIAAgMIAKAAIAAAMIA8AAIAAAIIg8AAIAAAKIAwAAIAAAmIgLAAIAXATIgHAHIgIgIIgNAAIAAANIAeAAIAAAIIgeAAIAAANQAAAGgBAEQgCADgEABQgDACgIgBgAAFAMIAkgBIgGgGIAEgEIgiAAgAAFgFIAlAAIAAgJIglAAgAgqgFIAlAAIAAgJIglAAgAAFgWIAlAAIAAgIIglAAgAgqgWIAlAAIAAgIIglAAg");
	this.shape_5.setTransform(24.875,147.8);

	this.instance = new lib.ClipGroup_1();
	this.instance.setTransform(65.85,59.2,1,1,0,0,0,103.7,77.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF2A0C").ss(2).p("AJfAAQAAD7iyCyQiyCyj7AAQj6AAiyiyQiyiyAAj7QAAj6CyiyQCyiyD6AAQD7AACyCyQCyCyAAD6g");
	this.shape_6.setTransform(60.675,60.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-37.8,-18.7,207.3,173.7), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhMSATzMAAAgnlMCYlAAAMAAAAnlg");
	mask.setTransform(488.325,181.8);

	// Layer_3
	this.instance = new lib.ClipGroup_2();
	this.instance.setTransform(697.85,154.7,1,1,0,0,0,275.1,154.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0E6E9").s().p("EhMSATzMAAAgnlMCYlAAAMAAAAnlg");
	this.shape.setTransform(488.35,182.175);

	var maskedShapeInstanceList = [this.instance,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(0.1,55.1,976.6,253.4), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egj6AUAMAAAgn/MBH1AAAMAAAAn/g");
	mask.setTransform(232.15,172.175);

	// Layer_3
	this.instance = new lib.ClipGroup_3();
	this.instance.setTransform(230.9,195.3,1,1,0,0,0,230.9,195.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(2.3,44.2,459.5,256), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egj6AUAMAAAgn/MBH1AAAMAAAAn/g");
	mask.setTransform(250.5,168.925);

	// Layer_3
	this.instance = new lib.ClipGroup_4();
	this.instance.setTransform(240.3,203.2,1,1,0,0,0,240.3,203.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(20.6,40.9,459.79999999999995,256.1), null);


// stage content:
(lib._970x250_200k = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTBdQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAizQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAIAnAAQAAAAABAAQABAAAAABQAAAAABABQAAAAAAABIAACzQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAg");
	this.shape.setTransform(64.025,51.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA+BdQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAhcQAAghgJgJQgJgJgaAAIhGAAQgBAAgBAAQAAAAgBABQAAAAAAABQAAAAAAABIAACMQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAIgoAAQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAAAAAgBIAAizQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAIBxAAQAcAAAPACQAXAEAKALQAKAKAEAWQADAQAAAbIAABaQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAg");
	this.shape_1.setTransform(47.725,51.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUA5QgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAgBIAAhrQAAgBAAgBQABAAAAAAQAAgBABAAQAAAAABAAIApAAQAAAAABAAQABAAAAABQAAAAABAAQAAABAAABIAABrQAAABAAABQgBAAAAABQAAAAgBAAQgBAAAAAAg");
	this.shape_2.setTransform(47.725,55.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6900").s().p("AhsDqQg0gLgfgfQgfgfgMg0QgIgmAAhHQAAhGAIgmQAMg0AfgeQAfggA0gLQAmgJBGAAQBHABAmAHQA0AMAfAfQAfAgAMAzQAIAmAABGQAABHgIAmQgMA0gfAfQgfAfg0ALQgmAJhHgBQhHABglgJg");
	this.shape_3.setTransform(51.875,51.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(325));

	// whiteCorss
	this.instance = new lib.Symbol1();
	this.instance.setTransform(485,125,1,1,0,0,0,488.3,126.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.7778},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.4444},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.2222},0).wait(1).to({alpha:0.1111},0).wait(1).to({alpha:0},0).wait(56).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(56).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(56).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(81).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1));

	// phoneMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AP5P9IhQ6iQAAgTAHgRQAJgRAQgLIBRg6QAWgOAZgCQAZgCAXAMILdGIQA4AeAiA1QAkA1AGA/IB5TTgAucP9IBR9NQADhIA1gzQA1gxBIAAIUnAEQBPAAA4A2QA5A3ADBPIBQc5gEghSAP5IBEqoQABgLgBgLIAAgIQgCgbACgbIAunxQAEgrAYgkQAYgjAlgUIMgmrQASgJATABQATABAQALIBZA8QAPAKAJARQAHARgBATIhNafg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:694.7,y:153.6998}).wait(75).to({graphics:null,x:0,y:0}).wait(250));

	// phoneLight
	this.instance_1 = new lib.Symbol13();
	this.instance_1.setTransform(1064.7,132.4,1,1,0,0,0,196.8,132.4);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({x:1047.45,alpha:0.9783},0).wait(1).to({x:1030.25,alpha:0.9565},0).wait(1).to({x:1013.05,alpha:0.9348},0).wait(1).to({x:995.85,alpha:0.913},0).wait(1).to({x:978.6,alpha:0.8913},0).wait(1).to({x:961.4,alpha:0.8696},0).wait(1).to({x:944.2,alpha:0.8478},0).wait(1).to({x:927,alpha:0.8261},0).wait(1).to({x:909.75,alpha:0.8043},0).wait(1).to({x:892.55,alpha:0.7826},0).wait(1).to({x:875.35,alpha:0.7609},0).wait(1).to({x:858.15,alpha:0.7391},0).wait(1).to({x:840.9,alpha:0.7174},0).wait(1).to({x:823.7,alpha:0.6957},0).wait(1).to({x:806.5,alpha:0.6739},0).wait(1).to({x:789.3,alpha:0.6522},0).wait(1).to({x:772.05,alpha:0.6304},0).wait(1).to({x:754.85,alpha:0.6087},0).wait(1).to({x:737.65,alpha:0.587},0).wait(1).to({x:720.45,alpha:0.5652},0).wait(1).to({x:703.2,alpha:0.5435},0).wait(1).to({x:686,alpha:0.5217},0).wait(1).to({x:668.8,alpha:0.5},0).wait(1).to({x:651.6,alpha:0.4783},0).wait(1).to({x:634.4,alpha:0.4565},0).wait(1).to({x:617.15,alpha:0.4348},0).wait(1).to({x:599.95,alpha:0.413},0).wait(1).to({x:582.75,alpha:0.3913},0).wait(1).to({x:565.55,alpha:0.3696},0).wait(1).to({x:548.3,alpha:0.3478},0).wait(1).to({x:531.1,alpha:0.3261},0).wait(1).to({x:513.9,alpha:0.3043},0).wait(1).to({x:496.7,alpha:0.2826},0).wait(1).to({x:479.45,alpha:0.2609},0).wait(1).to({x:462.25,alpha:0.2391},0).wait(1).to({x:445.05,alpha:0.2174},0).wait(1).to({x:427.85,alpha:0.1957},0).wait(1).to({x:410.6,alpha:0.1739},0).wait(1).to({x:393.4,alpha:0.1522},0).wait(1).to({x:376.2,alpha:0.1304},0).wait(1).to({x:359,alpha:0.1087},0).wait(1).to({x:341.75,alpha:0.087},0).wait(1).to({x:324.55,alpha:0.0652},0).wait(1).to({x:307.35,alpha:0.0435},0).wait(1).to({x:290.15,alpha:0.0217},0).wait(1).to({x:272.95,alpha:0},0).wait(15).to({_off:true},1).wait(250));

	// animate
	this.instance_2 = new lib.Symbol2();
	this.instance_2.setTransform(297.2,128.15,1,1,0,0,0,150.8,44.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},75).wait(250));

	// bg
	this.instance_3 = new lib.ClipGroup_32();
	this.instance_3.setTransform(484.95,97.5,1,1,0,0,0,488.3,154.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},75).wait(250));

	// text
	this.instance_4 = new lib.Image_1_1();
	this.instance_4.setTransform(512.15,207.45,0.1197,0.1197);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#030000").s().p("AiXA1QgLgJgCgRQgBgLADgJQAEgJANgHQALgGAbgBQAPgBASACQgBgMgCgDQgGgKgeADQgMABgYAHQgEADAAgFIAAgUQAAgBAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQARgHAagBQAogCAQAWQAKAOAAAXIAAAYQgCAQgFAJQgLAUgoABIgDAAQghAAgPgLgAiGAOQgCAEAAAGQAAAJAIADQAIAFAVgBQAUgCADgHQADgFAAgSQgTgCgMAAQgYABgGAHgAACAyQgPgPAAgiQAAghAPgPQAOgOAjAAQAiAAAOAOQAQAPAAAhQAAAigQAQQgOANgiAAQgjAAgOgOgAAXgcQgHAIAAAVQAAAXAHAHQAIAJAUAAQATAAAIgJQAHgHAAgXQAAgVgHgIQgIgJgTAAQgUAAgIAJgAF1A+QgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAh1QAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAABAAIAaAAQAAAAAAAAQABABAAAAQAAAAAAAAQABABAAAAIAAB1QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAgAEtA+QAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAg9QAAgYgCgEQgDgHgPAAQgNAAgEACQgFABgCAGQgBABAAAGIAABQQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgaAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAhQIgBgHQgCgGgEgBQgFgCgMAAQgPAAgEAHQgCAEAAAYIAAA9QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgaAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAhLQAAgPACgIQACgIAGgFQAMgKAdAAQAYAAANAHIAFAAQANgHAXAAQAeAAALALQAHAGACAKQABAGAAASIAABGQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAgAjkA+QgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAh1QAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAABAAIAaAAQAAAAAAAAQABABAAAAQAAAAAAAAQABABAAAAIAAB1QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAgAksA+IgCgBIgdgoIgfAoIgCABIghAAIgCgBIAAgCIAvg6Igvg5QAAAAgBgBQAAgBAAAAQABAAAAAAQABgBABAAIAhAAIACABIAeAoIAegoIACgBIAhAAQABAAABABQAAAAAAAAQAAAAAAABQAAABAAAAIguA4IAuA7QAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgCABg");
	this.shape_4.setTransform(245.8386,183.7678);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAGA9IAAgfIgzAAIAAgOIA3hMIASAAIAABJIASAAIAAARIgSAAIAAAfgAgXANIAdAAIAAgpg");
	this.shape_5.setTransform(307.375,183.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AADA9IAAhgIgcARIAAgWIAkgUIAQAAIAAB5g");
	this.shape_6.setTransform(296.75,183.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdApIAAgVQAMAIAOAAQAFAAAEgCQADgDAAgEQABgGgUgHQgVgGAAgSQAAgMAKgIQAJgHAOAAQANgBAMAGIAAAUQgLgIgNAAQgLAAAAAKQAAAEATAIQAVAGAAASQAAANgJAHQgLAIgOAAQgOAAgNgFg");
	this.shape_7.setTransform(364.1,185.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgcAiQgNgOAAgUQAAgTANgOQAMgNASABQASAAALAMQALAMAAAUIgBAIIg7AAQABAKAHAGQAIAGAKAAQAMAAAOgJIAAAUQgOAGgQAAQgTAAgNgMgAgMgWQgFAFgBAJIAmAAQgBgIgFgGQgFgGgHAAQgIAAgGAGg");
	this.shape_8.setTransform(355.325,185.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgKA/IAAhYIAVAAIAABYgAgIgoQgEgEAAgFQAAgGAEgEQAEgDAEAAQAGAAAEADQADAEAAAGQAAAFgDAEQgEAEgGAAQgEAAgEgEg");
	this.shape_9.setTransform(348.15,183.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgZAtIAAhYIAXAAIAAAJQAIgLAMABIAIAAIAAAUIgIgBQgMAAgIAMIAAA6g");
	this.shape_10.setTransform(342.7,185.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgbAiQgNgOgBgUQAAgTANgOQANgNASABQARAAALAMQAKAMAAAUIAAAIIg7AAQABAKAIAGQAHAGAKAAQANAAAOgJIAAAUQgPAGgQAAQgSAAgNgMgAgMgWQgFAFgBAJIAmAAQAAgIgGgGQgFgGgHAAQgIAAgGAGg");
	this.shape_11.setTransform(334.1,185.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmA3IAAgVQASALAQAAQAJAAAGgFQAHgFAAgIQAAgKgcgLQgfgKAAgXQAAgPANgKQAMgKASAAQAQAAASAGIAAAWQgQgKgQAAQgJAAgGAFQgGAEAAAIQAAAKAdAKQAeAKAAAYQAAAQgNAKQgMAKgTAAQgTAAgRgIg");
	this.shape_12.setTransform(324.4,183.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAAQABgDAEAAQAGAAgBADQABAEgGAAQgEAAgBgEg");
	this.shape_13.setTransform(380.1,200.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgdAbIgQgFQgEAFgJAAQgMAAABgIQAAgFAJAAQAFAAAFABQAEgLABgFIgIgCIABgDIAIABQAGgaAPABQAJABAAAHQAAAPgUAGQgDAKgDAGIgBACIAOAFQASAEAQAAQApAAAVgHIABADQgdAJgjAAQgPAAgUgEgAhBAUQAAADAFAAQADgBAEgDQgDgBgEAAQgBAAgBAAQgBAAgBAAQAAABAAAAQgBAAAAABgAgfgPIgCAKQANgDABgNQAAgFgEAAQgEAAgEALg");
	this.shape_14.setTransform(379.374,201.7745);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAAAJIgCgDQgFAFgHABQgEAAgCgDIgBgDQgIAFgIABQgMgBAAgIQAAgFAEgEQAFgEAHAAQAJAAAAAGQAAAGgMABIgDAAIAAABQAAAEAFgBQAIAAAFgEIAEgNIAKAAIgEAOQAAAAAAABQAAAAABAAQAAABAAAAQABAAAAAAQADAAADgDIAAgBQAAgEADgEQAFgEAGAAQAEAAACABIgBAFQgBgBAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgBAEIgCAEQAAAEAEAAQAEAAADgDIAAgCQABgDADgEQAFgEAGgBQAFABABACIABgCIAJAAIgEAOQAAAAAAAAQAAABAAAAQABAAAAAAQAAABABAAIADgCIABADQgEAEgFAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBIgBgCQgDAEgFAAQgEAAgDgDIgCgCQgFAGgHAAQgEAAgCgDgAAdgCIgBAFQAAABAAABQAAAAAAABQABAAAAAAQABAAAAAAQAGAAABgKQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAAAgBAAQgDgBgCAFgAglgDIgBADQAHABABgGQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAgBAAQgDAAgBAEg");
	this.shape_15.setTransform(381.175,202.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF2A0C").s().p("Ag5A6QgYgYAAgiQAAghAYgYQAYgYAhAAQAiAAAYAYQAYAYAAAhQAAAigYAYQgYAYgiAAQghAAgYgYg");
	this.shape_16.setTransform(379.575,202.325);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#030000").s().p("AAJAVIAAgUIgRAAIAAAUIgGAAIAAgpIAGAAIAAASIARAAIAAgSIAGAAIAAApg");
	this.shape_17.setTransform(365.825,202.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#030000").s().p("AgCAVIAAgjIgLAAIAAgGIAbAAIAAAGIgLAAIAAAjg");
	this.shape_18.setTransform(361.75,202.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#030000").s().p("AgCAVIAAgpIAFAAIAAApg");
	this.shape_19.setTransform(358.875,202.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#030000").s().p("AAHAVIgHgdIgGAdIgHAAIgKgpIAFAAIAIAhIAIghIAFAAIAIAhIAHghIAGAAIgKApg");
	this.shape_20.setTransform(354.95,202.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#030000").s().p("AgPAVIAAgpIAMAAQAIABADADQAIAGAAAKQAAAKgHAGQgFAFgLAAgAgIAPIAIAAQAGgCACgHIABgGQAAgLgIgCIgIgBIgBAAg");
	this.shape_21.setTransform(347.725,202.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_22.setTransform(343.625,202.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#030000").s().p("AAHAVIgIgRIgGAAIAAARIgGAAIAAgpIAPABQAFAAAEAGIACAFQAAAEgCADIgEACIgCACIAJASgAgHgBIAFAAQAIABAAgIQAAgEgDgBIgIgBIgCAAg");
	this.shape_23.setTransform(339.75,202.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_24.setTransform(335.75,202.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_25.setTransform(331.975,202.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#030000").s().p("AAJAVIgRgfIAAAfIgGAAIAAgpIAGAAIARAeIAAgeIAGAAIAAApg");
	this.shape_26.setTransform(327.625,202.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#030000").s().p("AgCAVIAAgpIAFAAIAAApg");
	this.shape_27.setTransform(324.175,202.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#030000").s().p("AgKAQQgFgHAAgJQAAgMAIgGQAEgCAEAAQAKAAADAHIACAGIgGAAQgCgGgDgBIgDAAQgFAAgDAEQgDAEAAAGQAAAQALAAQAFgBAEgCIAAgIIgIAAIAAgFIANAAIAAAQIgDACQgFADgGAAQgIAAgEgFg");
	this.shape_28.setTransform(320.775,202.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#030000").s().p("AAJAVIgSgfIAAAfIgFAAIAAgpIAGAAIARAeIAAgeIAGAAIAAApg");
	this.shape_29.setTransform(316.25,202.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAQAAIAAAEIgQAAIAAANIARAAIAAAGg");
	this.shape_30.setTransform(312.175,202.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#030000").s().p("AgHATQgJgGAAgNQAAgLAIgHQAEgCAEAAQAIAAAEAEQAFAGABAKQAAANgJAFQgDADgGAAQgEAAgDgCgAgEgNQgEABgBAHIgBAFQAAAGACAEIADADQACACADABQAGAAADgGQACgFAAgFQAAgIgFgEQgCgCgEAAIgEABg");
	this.shape_31.setTransform(305.65,202.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#030000").s().p("AgFATQgKgFAAgOQAAgLAIgGQADgDAGAAQAIAAAEAHIABAGIgFAAIgBgDQgDgEgEAAQgEAAgDACQgDAFAAAHQgBAJAFAFQADACADAAQACgBACgBQAEgCAAgGIAGAAQAAAGgDAEQgEAFgHAAQgEAAgDgCg");
	this.shape_32.setTransform(301.25,202.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#030000").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_33.setTransform(309.05,202.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AiCB7QAagTAPgTQANgQAFgUQAFgSABghIhEAAIAAgYIBEAAIAAhEIg5AJIgFgXQAtgGAegGQAmgGAfgIIAGAWQgNAEgyAJIAABJIBZAAIAAhzIAYAAIAABzIA9AAIAAAYIg9AAIAACNIgYAAIAAiNIhZAAQgBAjgGAYQgHAXgOAUQgQAUgbAWg");
	this.shape_34.setTransform(383.2,130.875);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhGB+QAOgQAIgNQAHgMAFgPQAEgSADgUIAVACQgCAPgDANQAKAVAJALQALALAQADIAAhWIhVAAIAAgUIC6AAIAAAUIhPAAIAAAfIBCAAIAAAUIhCAAIAAAmIBTAAIgFAVIhLAAQgfAAgQgKQgRgJgOgZQgFANgIANQgLAQgJAKgAiCCHIgEgXIAPAAQALAAAEgDQADgDAAgIIAAhSIghANIgDgYIAkgMIAAg2IggAAIAAgWIAgAAIAAg4IAXAAIAAA4IAdAAIAAAWIgdAAIAAAuIAagLIACAYIgcAKIAABiQAAALgDAHQgDAFgIADQgIADgMAAgAgcgWIAAhqICLAAIAABqgAgGgpIBfAAIAAgZIhfAAgAgGhUIBfAAIAAgZIhfAAg");
	this.shape_35.setTransform(352.1,130.825);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AhdCOIAAjOIgRAAIAACUIgTAAIAAiqIAkAAIAAg2IAVAAIAAA2IAnAAIAACTQAAAMgFAGQgEAEgMAAIgKAAIgEgUIAIAAQAFAAABgCIABgIIAAh1IgTAAIAADOgABmCNIAAgQIhlAAIAAAQIgUAAIAAiGICOAAIAACGgAA9BrIApAAIAAggIgpAAgAABBrIAoAAIAAggIgoAAgAA9A5IApAAIAAgfIgpAAgAABA5IAoAAIAAgfIgoAAgAgHgQIAAhCIB1AAIAABCgAAMgjIBOAAIAAgcIhOAAgAgZhoIAAgVICcAAIAAAVg");
	this.shape_36.setTransform(321.35,130.75);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AiIB2QA3gfAfgnQAhgnAEgxIh2AAIAAgYIB2AAIAAhMIAYAAIAABMIB3AAIAAAYIh3AAIAAAEQAKAyAeAkQAfAlA3AeIgPAXQhdg2gchOQgNAnggAiQggAhgsAbg");
	this.shape_37.setTransform(290.175,130.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AiGCFIAAgRIB8AAIAAgQIhnAAIAAgRIBnAAIAAgRIheAAIAAhLIDRAAIAABLIheAAIAAARIBnAAIAAARIhnAAIAAAQIB8AAIAAARgAALAzIBHAAIAAgQIhHAAgAhRAzIBHAAIAAgQIhHAAgAALAUIBHAAIAAgQIhHAAgAhRAUIBHAAIAAgQIhHAAgAiJgaIAAgQIETAAIAAAQgAhog7IAAhJIDRAAIAABJgAhRhJICjAAIAAgPIijAAgAhRhnICjAAIAAgNIijAAg");
	this.shape_38.setTransform(259.075,130.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AiHB4QAggQARgNQAQgOAIgTQAIgUAAgfIABgGIhNAAIAAgXIB6AAIAAh2IAXAAIAAB2IB5AAIAAAXIhbAAIAABVQAAAMAFAEQAFAFAMAAIAUAAQAKAAAFgCQAFgBACgFQACgDABgKIAAglIAXAEIgCApQAAAPgFAIQgEAIgJADQgJADgQAAIgfAAQgPAAgIgDQgHgDgEgJQgEgJAAgOIAAhcIgyAAIAAAHQgCAjgIAXQgJAXgRASQgTARghARgAhvhqIASgOIA1BBIgTAPgAAug5QAdggAXghIATAPQgWAfgeAjg");
	this.shape_39.setTransform(227.775,130.725);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AiHB0IAhgoIAAhUIghAAIAAgXIA4AAIAABqQAKAQAMAIQALAIAMACQANADAVAAICIAAIgFAWIiGAAQgWAAgOgDQgNgCgOgJQgNgIgLgPIghApgAglBRIAAh8QgFAKgSAYIgKgWQARgUAOgcQAQgdAIgdIATAEQgFAVgJATIA6AAQgIgbgHgLIAUgGIADAGQAKAaAEAMIA4AAIAAAUIg/AAIAAAgIA6AAIAAAUIg6AAIAAAcIA6AAIAAAUIg6AAIAAAiIBDAAIAAAUgAgOA9IA3AAIAAgiIg3AAgAgOAHIA3AAIAAgcIg3AAgAgOgpIA3AAIAAggIg3AAgAh+h3IASgNQAeAnAOAUIgTANg");
	this.shape_40.setTransform(197.1,130.45);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AghCEIh+AQIgFgnIBFgIIAlhSIAgAMQgJAWgVArIApgFIABAeQAcgOAYgPIgpAAIAAi+IAvAAIAHgcIg+AAIAAgjICpAAIAAAjIhGAAIgGAcIBBAAIAAC+IgtAAQAsAZATANIgRAfQgTgPgygdIAQgZIg0AAIASAbQgzAegaANgAAgA7IBQAAIAAgWIhQAAgAAgAHIBQAAIAAgWIhQAAgAAggsIBQAAIAAgXIhQAAgAiHA8QgHgRgHgLIAegOIAfA7IggAQgAiXAPIAAhtIB/AAIAABtgAhzgSIA2AAIAAgqIg2AAgAieh7IAAgkICJAAIAAAkg");
	this.shape_41.setTransform(436.5,86.95);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("Ag6COIhiAPIgFghIAxgIIAAhkIgqAAIAAgeIAqAAIAAgbIgaAAIAAgRIgPASIgKgpQAQgQANgWQAMgTANgaIAcAAQANAPAiAwIgTAcQgWgigRgXQgPAcgUAcIBIAAIAAAhIgZAAIAAAbIAmAAIAAAeIgmAAIAABgIAkgHIACAeQAbgJAKgLQAKgMACgRIgiAAIAAh5ICpAAIAAB5IgqAAIAAAfQAAAJADAEQADADAIAAIAGAAQAKAAADgDQADgEAAgIIABgeIAbAGIgBAhQgBAUgJAJQgJAHgVAAIgXAAQgSAAgIgJQgIgHAAgSIAAgrIgZAAQgCAegTAUQgUAWgqAPgAAFA5IBoAAIAAgUIhoAAgAAFAMIBoAAIAAgSIhoAAgAifAlIAYgJIAVBBIgZAJQgKgpgKgYgAhOBdQAMglAFgcIAXAHQgGAYgMAogAgng0IAAgeIAqAAIgFgfIgdAAIAAgeIBHAAIgIgWIAlgHIAKAdIBKAAIAAAeIggAAQgCANgFASIAwAAIAAAegAAmhSIApAAIAIgfIg3AAg");
	this.shape_42.setTransform(400.675,86.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AAmBcIgmg8IgmA8Ig2AAIBAhcIg9hbIA1AAIAkA5IAkg5IA1AAIg+BbIBCBcg");
	this.shape_43.setTransform(361.25,91.275);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("Ag/BMQgTgTAAgdIAAh5IAvAAIAABwQAAAPAJAKQAJAJAPAAQASAAAUgTIAAh/IAvAAIAAC2IgvAAIAAgQQgZAVgcAAQgdAAgRgSg");
	this.shape_44.setTransform(341.6,91.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgXCEIAAkHIAuAAIAAEHg");
	this.shape_45.setTransform(326.9,87.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgWCCIAAi2IAuAAIAAC2gAgShUQgIgHAAgMQAAgMAIgHQAHgHALgBQAMABAHAHQAIAHAAAMQAAAMgIAHQgHAIgMAAQgLAAgHgIg");
	this.shape_46.setTransform(317.975,87.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("ABZBeIAAhzQAAgNgHgKQgIgIgNAAQgUAAgRATIAAB/IguAAIAAhzQAAgNgIgKQgJgIgMAAQgTAAgSATIAAB/IgwAAIAAi3IAwAAIAAAPQAXgTAdAAQAiAAAQAcQAdgcAhAAQAbAAARASQARASAAAdIAAB6g");
	this.shape_47.setTransform(297.9,91.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("ABZBeIAAhzQABgNgJgKQgHgIgNAAQgTAAgSATIAAB/IguAAIAAhzQgBgNgHgKQgJgIgNAAQgSAAgTATIAAB/IguAAIAAi3IAuAAIAAAPQAYgTAdAAQAiAAARAcQAcgcAhAAQAbAAAQASQASASgBAdIAAB6g");
	this.shape_48.setTransform(266.55,91.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AhABMQgSgTAAgdIAAh5IAvAAIAABwQAAAPAJAKQAJAJAOAAQAUAAASgTIAAh/IAwAAIAAC2IgwAAIAAgQQgZAVgbAAQgdAAgSgSg");
	this.shape_49.setTransform(240.45,91.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AhPByIAAgtQAkAXAiAAQAUAAANgKQANgKAAgQQAAgRgTgKQgFgDgkgNQg9gWAAgwQAAggAZgUQAZgVAnAAQAhAAAjAOIAAAsQgggTghAAQgTAAgNAJQgMAJAAAQQAAAQATAKIApAQQA9AVAAAxQAAAigZAVQgaAVgnAAQgmAAgkgRg");
	this.shape_50.setTransform(220.475,87.825);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgmCpIAAimIh8AAIAAgmIB8AAIAAiFIArAAIAAAtICAAAIAAAmIiAAAIAAAyICeAAIAAAmIieAAIAACmgAAHA3IASggIB2BDIgVAkg");
	this.shape_51.setTransform(180.45,86.225);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AAaCqIAAhnQgcAqg4AsIgXghQBLg1AghBIAAhbIhTAAIAAgmIBTAAIAAgoIAmAAIAAAoIBeAAIAAAmIheAAIAABiQAfA1BFA3IgWAiQgwgmgegrIAABkgAh7CoIAAh/QgSAVgIAJIgPgoQASgTAYghQAXgfAPgbIAdAUQgMAXgVAfIAACtgAhJAVQAfguAKg0IAgAEQgCASgGAQIAgAnIgVAYIgYgcQgKAXgRAZgABugHQgMAVgIANIgYgYQANgSAIgUQAJgSAHgZIAeAHQgEARgFAOQAVAYAUAYIgUAdQgPgWgUgWgAijhRQARgQAYgbQAYgdALgQIAaAZQgOAWgYAcQgaAdgVAVg");
	this.shape_52.setTransform(144.625,86.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_4}]},75).to({state:[]},75).wait(175));

	// bg
	this.instance_5 = new lib.ClipGroup_16();
	this.instance_5.setTransform(732.1,160.2,1,1,0,0,0,240.3,203.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(75).to({_off:false},0).to({_off:true},75).wait(175));

	// text
	this.instance_6 = new lib.Image_3();
	this.instance_6.setTransform(511.9,208,0.1127,0.1127);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#030000").s().p("AiXA1QgLgJgCgRQgBgLADgJQAEgJANgHQALgGAbgBQAPgBASACQgBgMgCgDQgGgKgeADQgMABgYAHQgEADAAgFIAAgUQAAgBAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQARgHAagBQAogCAQAWQAKAOAAAXIAAAYQgCAQgFAJQgLAUgoABIgDAAQghAAgPgLgAiGAOQgCAEAAAGQAAAJAIADQAIAFAVgBQAUgCADgHQADgFAAgSQgTgCgMAAQgYABgGAHgAACAyQgPgPAAgiQAAghAPgPQAOgOAjAAQAiAAAOAOQAQAPAAAhQAAAigQAQQgOANgiAAQgjAAgOgOgAAXgcQgHAIAAAVQAAAXAHAHQAIAJAUAAQATAAAIgJQAHgHAAgXQAAgVgHgIQgIgJgTAAQgUAAgIAJgAF1A+QgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAh1QAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAABAAIAaAAQAAAAAAAAQABABAAAAQAAAAAAAAQABABAAAAIAAB1QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAgAEtA+QAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAg9QAAgYgCgEQgDgHgPAAQgNAAgEACQgFABgCAGQgBABAAAGIAABQQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgaAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAhQIgBgHQgCgGgEgBQgFgCgMAAQgPAAgEAHQgCAEAAAYIAAA9QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgaAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAhLQAAgPACgIQACgIAGgFQAMgKAdAAQAYAAANAHIAFAAQANgHAXAAQAeAAALALQAHAGACAKQABAGAAASIAABGQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAgAjkA+QgBAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAh1QAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAABAAIAaAAQAAAAAAAAQABABAAAAQAAAAAAAAQABABAAAAIAAB1QAAABgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAgAksA+IgCgBIgdgoIgfAoIgCABIghAAIgCgBIAAgCIAvg6Igvg5QAAAAgBgBQAAgBAAAAQABAAAAAAQABgBABAAIAhAAIACABIAeAoIAegoIACgBIAhAAQABAAABABQAAAAAAAAQAAAAAAABQAAABAAAAIguA4IAuA7QAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgCABg");
	this.shape_53.setTransform(245.8386,183.7678);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AAGA9IAAgfIgzAAIAAgOIA3hMIASAAIAABJIASAAIAAARIgSAAIAAAfgAgXANIAdAAIAAgpg");
	this.shape_54.setTransform(307.375,183.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AADA9IAAhgIgcARIAAgWIAkgUIAQAAIAAB5g");
	this.shape_55.setTransform(296.75,183.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgdApIAAgVQAMAIAOAAQAFAAAEgCQADgDAAgEQABgGgUgHQgVgGAAgSQAAgMAKgIQAJgHAOAAQANgBAMAGIAAAUQgLgIgNAAQgLAAAAAKQAAAEATAIQAVAGAAASQAAANgJAHQgLAIgOAAQgOAAgNgFg");
	this.shape_56.setTransform(364.1,185.55);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgcAiQgNgOAAgUQAAgTANgOQAMgNASABQASAAALAMQALAMAAAUIgBAIIg7AAQABAKAHAGQAIAGAKAAQAMAAAOgJIAAAUQgOAGgQAAQgTAAgNgMgAgMgWQgFAFgBAJIAmAAQgBgIgFgGQgFgGgHAAQgIAAgGAGg");
	this.shape_57.setTransform(355.325,185.55);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgKA/IAAhYIAVAAIAABYgAgIgoQgEgEAAgFQAAgGAEgEQAEgDAEAAQAGAAAEADQADAEAAAGQAAAFgDAEQgEAEgGAAQgEAAgEgEg");
	this.shape_58.setTransform(348.15,183.675);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgZAtIAAhYIAXAAIAAAJQAIgLAMABIAIAAIAAAUIgIgBQgMAAgIAMIAAA6g");
	this.shape_59.setTransform(342.7,185.45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgbAiQgNgOgBgUQAAgTANgOQANgNASABQARAAALAMQAKAMAAAUIAAAIIg7AAQABAKAIAGQAHAGAKAAQANAAAOgJIAAAUQgPAGgQAAQgSAAgNgMgAgMgWQgFAFgBAJIAmAAQAAgIgGgGQgFgGgHAAQgIAAgGAGg");
	this.shape_60.setTransform(334.1,185.55);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgmA3IAAgVQASALAQAAQAJAAAGgFQAHgFAAgIQAAgKgcgLQgfgKAAgXQAAgPANgKQAMgKASAAQAQAAASAGIAAAWQgQgKgQAAQgJAAgGAFQgGAEAAAIQAAAKAdAKQAeAKAAAYQAAAQgNAKQgMAKgTAAQgTAAgRgIg");
	this.shape_61.setTransform(324.4,183.875);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgFAAQABgDAEAAQAGAAgBADQABAEgGAAQgEAAgBgEg");
	this.shape_62.setTransform(380.1,200.575);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgdAbIgQgFQgEAFgJAAQgMAAABgIQAAgFAJAAQAFAAAFABQAEgLABgFIgIgCIABgDIAIABQAGgaAPABQAJABAAAHQAAAPgUAGQgDAKgDAGIgBACIAOAFQASAEAQAAQApAAAVgHIABADQgdAJgjAAQgPAAgUgEgAhBAUQAAADAFAAQADgBAEgDQgDgBgEAAQgBAAgBAAQgBAAgBAAQAAABAAAAQgBAAAAABgAgfgPIgCAKQANgDABgNQAAgFgEAAQgEAAgEALg");
	this.shape_63.setTransform(379.374,201.7745);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAAAJIgCgDQgFAFgHABQgEAAgCgDIgBgDQgIAFgIABQgMgBAAgIQAAgFAEgEQAFgEAHAAQAJAAAAAGQAAAGgMABIgDAAIAAABQAAAEAFgBQAIAAAFgEIAEgNIAKAAIgEAOQAAAAAAABQAAAAABAAQAAABAAAAQABAAAAAAQADAAADgDIAAgBQAAgEADgEQAFgEAGAAQAEAAACABIgBAFQgBgBAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgBAEIgCAEQAAAEAEAAQAEAAADgDIAAgCQABgDADgEQAFgEAGgBQAFABABACIABgCIAJAAIgEAOQAAAAAAAAQAAABAAAAQABAAAAAAQAAABABAAIADgCIABADQgEAEgFAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBIgBgCQgDAEgFAAQgEAAgDgDIgCgCQgFAGgHAAQgEAAgCgDgAAdgCIgBAFQAAABAAABQAAAAAAABQABAAAAAAQABAAAAAAQAGAAABgKQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAAAgBAAQgDgBgCAFgAglgDIgBADQAHABABgGQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAgBAAQgDAAgBAEg");
	this.shape_64.setTransform(381.175,202.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FF2A0C").s().p("Ag5A6QgYgYAAgiQAAghAYgYQAYgYAhAAQAiAAAYAYQAYAYAAAhQAAAigYAYQgYAYgiAAQghAAgYgYg");
	this.shape_65.setTransform(379.575,202.325);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#030000").s().p("AAJAVIAAgUIgRAAIAAAUIgGAAIAAgpIAGAAIAAASIARAAIAAgSIAGAAIAAApg");
	this.shape_66.setTransform(365.825,202.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#030000").s().p("AgCAVIAAgjIgLAAIAAgGIAbAAIAAAGIgLAAIAAAjg");
	this.shape_67.setTransform(361.75,202.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#030000").s().p("AgCAVIAAgpIAFAAIAAApg");
	this.shape_68.setTransform(358.875,202.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#030000").s().p("AAHAVIgHgdIgGAdIgHAAIgKgpIAFAAIAIAhIAIghIAFAAIAIAhIAHghIAGAAIgKApg");
	this.shape_69.setTransform(354.95,202.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#030000").s().p("AgPAVIAAgpIAMAAQAIABADADQAIAGAAAKQAAAKgHAGQgFAFgLAAgAgIAPIAIAAQAGgCACgHIABgGQAAgLgIgCIgIgBIgBAAg");
	this.shape_70.setTransform(347.725,202.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_71.setTransform(343.625,202.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#030000").s().p("AAHAVIgIgRIgGAAIAAARIgGAAIAAgpIAPABQAFAAAEAGIACAFQAAAEgCADIgEACIgCACIAJASgAgHgBIAFAAQAIABAAgIQAAgEgDgBIgIgBIgCAAg");
	this.shape_72.setTransform(339.75,202.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_73.setTransform(335.75,202.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAPAAIAAAEIgPAAIAAANIARAAIAAAGg");
	this.shape_74.setTransform(331.975,202.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#030000").s().p("AAJAVIgRgfIAAAfIgGAAIAAgpIAGAAIARAeIAAgeIAGAAIAAApg");
	this.shape_75.setTransform(327.625,202.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#030000").s().p("AgCAVIAAgpIAFAAIAAApg");
	this.shape_76.setTransform(324.175,202.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#030000").s().p("AgKAQQgFgHAAgJQAAgMAIgGQAEgCAEAAQAKAAADAHIACAGIgGAAQgCgGgDgBIgDAAQgFAAgDAEQgDAEAAAGQAAAQALAAQAFgBAEgCIAAgIIgIAAIAAgFIANAAIAAAQIgDACQgFADgGAAQgIAAgEgFg");
	this.shape_77.setTransform(320.775,202.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#030000").s().p("AAJAVIgSgfIAAAfIgFAAIAAgpIAGAAIARAeIAAgeIAGAAIAAApg");
	this.shape_78.setTransform(316.25,202.3);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#030000").s().p("AgLAVIAAgpIAXAAIAAAGIgRAAIAAAMIAQAAIAAAEIgQAAIAAANIARAAIAAAGg");
	this.shape_79.setTransform(312.175,202.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#030000").s().p("AgHATQgJgGAAgNQAAgLAIgHQAEgCAEAAQAIAAAEAEQAFAGABAKQAAANgJAFQgDADgGAAQgEAAgDgCgAgEgNQgEABgBAHIgBAFQAAAGACAEIADADQACACADABQAGAAADgGQACgFAAgFQAAgIgFgEQgCgCgEAAIgEABg");
	this.shape_80.setTransform(305.65,202.3);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#030000").s().p("AgFATQgKgFAAgOQAAgLAIgGQADgDAGAAQAIAAAEAHIABAGIgFAAIgBgDQgDgEgEAAQgEAAgDACQgDAFAAAHQgBAJAFAFQADACADAAQACgBACgBQAEgCAAgGIAGAAQAAAGgDAEQgEAFgHAAQgEAAgDgCg");
	this.shape_81.setTransform(301.25,202.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#030000").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_82.setTransform(309.05,202.775);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("ABUByIAAgKIinAAIAAAKIgTAAIAAjiIDNAAIAADigAhTBXICnAAIAAi2IinAAgAgXBJQgNAAgFgEQgFgFAAgMIAAgkQgMAJgPAHIgHgPQAcgNAPgPIglAAIAAgPIAwAAIAIgPIgzAAIAAgOIAhAAIgXgZIALgKIAXAZIgLAKIAXAAQAGgSACgSIAPABQgDATgEAQIAfAAIgKgJQAOgMALgNIALAKQgHAIgRAQIAhAAIAAAOIhFAAIgHAPIBSAAIAAAPIgmAAQASATAaAIIgHAPQgSgIgSgPIgCATQgBALgEADQgFAEgNAAIgWAAIgCgNIAVAAQAHAAACgBQADgCAAgFIABgHIg1AAIAAAdQAAAHADADQACADAJAAIAqAAIALgBQADgCABgDIACgIIAAgMIAQADIAAARQgBAIgDAEQgCAEgFACQgGACgKAAgAgfAEIBAAAQgHgGgIgJIgjAAIgOAPg");
	this.shape_83.setTransform(411.375,131.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AhxBkQAcgOAMgKQANgLAIgQQAGgSABgZIAAgGIhBAAIAAgTIBnAAIAAhiIATAAIAABiIBmAAIAAATIhMAAIAABHQAAALAEAEQAEADAKAAIAQAAQAKABADgCQAFgCABgDQACgFAAgGIABgfIATADIgCAjQgBANgDAGQgCAGgJADQgIADgNAAIgaAAQgMAAgHgDQgHgDgDgGQgCgJAAgLIAAhOIgrAAIAAAHQgCAfgGARQgHAVgPANQgRAQgaANgAhdhZIAPgMIAsA3IgQAMgAAmgvQAagcASgbIAQAMQgQAWgcAhg");
	this.shape_84.setTransform(385.125,130.65);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AhyBjQAsgZAdgiQAbgiADgnIhiAAIAAgUIBjAAIAAhBIATAAIAABBIBkAAIAAAUIhkAAIAAADQAJAqAZAeQAaAfAuAZIgNAUQhNgugYhCQgLAhgbAcQgaAcgmAYg");
	this.shape_85.setTransform(359.425,130.6);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgKA6IAAgwIgwAAIAAgTIAwAAIAAgxIAVAAIAAAxIAwAAIAAATIgwAAIAAAwg");
	this.shape_86.setTransform(329.075,130.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AhSB5IAAiGQgLATgOATIgIgXQAPgVAPgiQAQgkAHgfIATAHQgHAdgMAdIAACwgAAgB4IAAhSIhNAAIAAgUIBNAAIAAg9IgoAAQgLAggFAMIgUgIQAIgUAKgaQAIgbAFgXIASAEIgIAkIAjAAIAAg5IAUAAIAAA5IA4AAIAAAUIg4AAIAAA9IBAAAIAAAUIhAAAIAABSg");
	this.shape_87.setTransform(298.675,130.525);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AhwBdQAZgOAMgMQAOgMAEgPQAFgLABgXIABgaIg+AAIAAgUIDhAAIAAAUIhMAAIAABTQAAAKAEAFQAEAEALAAIAPAAQAJgBAEgBQAEgCACgDQACgGAAgGIABgiIAUAFIgBAlQgCAMgDAHQgDAGgIADQgJADgNgBIgYAAQgSAAgIgHQgHgIAAgTIAAhXIgvAAIAAAaQgBAYgGARQgGARgOAQQgQAQgZAOgAhahYIAAgVIC2AAIAAAVg");
	this.shape_88.setTransform(272.825,131.35);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AhxBkQAbgNAOgLQAOgMAGgPQAGgPABgcIAAgGIhAAAIAAgTIBmAAIAAhiIATAAIAABiIBmAAIAAATIhMAAIAABHQAAAKAEAFQAEADAKAAIAQAAQAJABAFgCQAEgCACgDIACgLIAAgfIATADIgBAjQgBAMgDAHQgEAGgHADQgJADgNAAIgaAAQgMAAgHgDQgGgDgDgGQgDgIAAgMIAAhOIgqAAIgBAHQgBAdgHATQgGATgQAPQgPAPgcAOgAhdhZIAPgMIAWAbIAWAcIgQAMgAAngvQAagdARgaIAQAMQgUAcgYAbg");
	this.shape_89.setTransform(246.575,130.65);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgYB0QgRAAgGgFQgGgFAAgOIAAgpIASAAIAAAhQAAAJAEADQADADAKAAIApAAQALAAAEgDQAEgCABgIIABgWIASAEIgCAZQgBAJgEAGQgDAFgHABQgGACgNAAgAh0BnQAHgIAJgQQAFgJAIgSIARAHQgJAYgUAegABDA9IAPgKQAQAWARAaIgRAKQgSgggNgQgAgOAyIAMgLIAeAfIgNAOgAhtArQAIgMAFgOQAEgNABgNQACgQAAgXIAAgkIBxAAIgDgeIASgBIAEAfIAdAAIgJgYIAOgFIANAdIAXAAIAAARIhEAAIALA4QATgXAKgXIAQAIQgRAhgUAWIAHAMIAJAIQAEACADAAQADAAAEgFQADgFABgIIADgVIAQAGIgEAWQgHAegTABQgIgBgHgEQgJgFgHgKIgFgHQgOAOgMAHIgJgPIAbgXQgFgLgEgSIgIgqIhhAAIAAAZQAAAigEATQgFAUgMAXgAg5AhIAAgyIBEAAIAAAygAgqATIAnAAIAAgXIgnAAgAg9giIAAgPIBQAAIAAAPg");
	this.shape_90.setTransform(220.625,130.25);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AhyBjQAtgZAbgiQAbggAFgpIhjAAIAAgUIBjAAIAAhBIATAAIAABBIBkAAIAAAUIhkAAIAAADQAIApAaAfQAZAfAvAZIgNAUQhOgugYhCQgLAjgaAaQgbAdglAXg");
	this.shape_91.setTransform(194.9,130.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AhzBpQAMgWADgVQAEgVABgmIAQAAIgBAkQADAPAGAKQAFAKAIAGIAAhcIg2AAIAAgSIAuAAIAAglIgmAAIAAgSIAmAAIAAggIASAAIAAAgIAiAAIAAASIgiAAIAAAlIAmAAIAAASIgeAAIAAAmIAdAAIAAASIgdAAIAAAtQAMADAVAAIB7AAIgEATIh4AAQgfAAgSgJQgRgIgLgWQgFAYgJAWgAAEBFIAAhKIBhAAIAABKgAAWAzIA9AAIAAgoIg9AAgAgGggQAPgLAHgOQAHgMAEgSIgeAAIAAgRIBrAAIgCAyQgBALgDAHQgDAGgHACQgFADgNAAIgWAAIgEgSIASAAQAMAAAEgEQAEgDABgLIACgaIgqAAQgBATgJARQgIAQgUARg");
	this.shape_92.setTransform(168.725,130.625);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgrB4QAGgDADgDQABgDAAgIIAAj7ICcAAIAACaIhIAAQAHAWAMAUQAZgRAXgUIAUAYQggAbgSAKQAWAXAnAQIgUAfQgugZgZgeQgZgggOgxIgTAAIAABhIAvgWIAFAiIhQAkgAAAgYIBaAAIAAgeIhaAAgAAAhUIBaAAIAAghIhaAAgAiUCUIAAkqIBjAAIAAAfIgXBRQANAWAGASQAFAVAAASQAAAegKALQgLAMgZAAIgLAAIgJgiIAJAAQALAAAFgBQAFgCACgGQACgHAAgJQAAgOgGgSQgGgRgMgSIAVhWIggAAIAAEKg");
	this.shape_93.setTransform(440.575,87.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("Ah6B7QAVgIAMgKQANgLADgLQAFgMAAgPIAAgFQggARglANIgQgiQBDgSAwgkIhUAAIAAiQID2AAIAACQIhVAAQAWAQAbANQAcANAmAKIgPAiQgngNgagNIAABfIgmAAIAAhpIAVAAQgkgTgUgVQgTATgkAVIAXAAIAAANQAAAegQAZQgRAYgkARgAASgmIBGAAIAAgbIhGAAgAhVgmIBFAAIAAgbIhFAAgAAShdIBGAAIAAgbIhGAAgAhVhdIBFAAIAAgbIhFAAg");
	this.shape_94.setTransform(406.6,87.125);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AATCBIgJAIQgRgWgTgSIAUgSQANAMAYAaQAhgWAWgXQAXgZAVgcIAZAVQgpA+hNA2gAhjCXIgHgdIAVAAQAMAAACgCQAEgEgBgJIAAgeIg/AAIAAhFICVAAIAABFIg2AAIAAApQAAAOgDAGQgDAIgIADQgIACgQAAgAhiA0IBUAAIAAgTIhUAAgAiaB7QAWgPAagfIAVATQgGAJgRASQgLAMgOAMgAAcATQAZgQAagXQAWgVATgZIAZAVQgTAagaAYQgYAZgbATgAiWgEIAAgbIBQAAIgHgRIg5AAIAAhkICaAAIAABkIg+AAIAGARIBHAAIAAAbgAhmhIIBbAAIAAgPIhbAAgAhmhsIBbAAIAAgPIhbAAgAAfhLQAWgQAVgUQAYgWARgWIAZAVQgUAZgYAYQgbAagTANg");
	this.shape_95.setTransform(373.45,86.75);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("ABuCaIAAgZIhEAFIgCgYIAKgBIAAhaIgHAAIAAgXIBsAAIAAAXIgOAAIAABUIAPgBIAAAYIgPABIAAAbgABLBrIAjgDIAAgNIgjAAgABLBHIAjAAIAAgQIgjAAgABLAjIAjAAIAAgQIgjAAgAAECaIAAgbQhAAFgNACIgDgYIAVgCIAAhZIgIAAIAAgXIBkAAIAAAXIgIAAIAABSIAJAAIAAAXIgJABIAAAdgAgdBqIAhgDIAAgNIghAAgAgdBEIAhAAIAAgOIghAAgAgdAiIAhAAIAAgPIghAAgAiPCXIgGglIAOAAQAJAAADgDQAEgCAAgJIAAhFIgZAJIgHgjIAggKIAAg5IgcAAIAAgkIAcAAIAAg2IAgAAIAAA2IAbAAIAAAkIgbAAIAAAtIAOgGIAEAjIgSAHIAABYQAAAXgIAKQgIALgWAAgABXgLIAAgLIiWAFIAAgXIAaAAIAAhSIgWAAIAAgZIDKAAIAAAZIgXAAIAABNIAdgBIABAXIgeABIAAALgAgDgpIBagDIAAgNIhaAAgAgDhMIBaAAIAAgNIhaAAgAgDhtIBaAAIAAgNIhaAAg");
	this.shape_96.setTransform(340.325,86.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AhACdIgGgeIAnAAQALAAAEgDQAEgDAAgJIAAgMIiIAAIAAgeICIAAIAAgGIApgUIh7AAIAAgbIC+AAIAAAaIg9AbIByAAIAAAeIh8AAIAAAUQAAAUgKAIQgKAJgYAAgABvAjIAAggIjbAAIAAAgIgiAAIAAg5IAUAAIgFhuQAPgCAXgHQAZgHALgEIAJAcIgxANIABAOIAsAAIAAAVIgsAAIABASIAqAAIAAAUIgpAAIABAQIA4AAIgNgVQAKgEASgMIgWgQIAHgJIgMgTQAQgJAMgIIgZgSIAOgRIAdAVQANgKAMgMIARARIgWASIAZASIgOASIAJAJIgUARIAYATIgPASQgMgKgRgMQgNAKgUAMIB8AAIAAgQIgpAAIAAgVIAqAAIABgRIgrAAIAAgVIAsAAIABgRIgwAAIAAgZIBRAAIgGB1IAWAAIAAA5gAgWhaIAXARIAIgHIAMgLIgUgPIgXAQg");
	this.shape_97.setTransform(307.125,86.075);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AiWB8QAggQASgOQASgPAHgUQAJgTAAghIAAgCIhMAAIAAgkIB/AAIAAh9IAlAAIAAB9IB+AAIAAAkIhbAAIAABVQAAALADAEQAGAEAKAAIATAAQAIAAAFgBQAEgCABgDQACgEAAgIIABgoIAjAGIgCAuQgBATgEAIQgEAKgLAEQgLAEgSAAIgkAAQgSAAgJgEQgJgFgFgKQgEgKAAgRIAAhhIguAAIAAADQgDAogIAZQgJAagUATQgTAUglATgAiAhzIAcgXIAfAkQASAVALAOIgdAYgAAuhFQAigkAYgjIAdAXQgdAogeAhg");
	this.shape_98.setTransform(273.7,86.575);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AhRCJQAYgbAIgTQAKgTAAgdIgZAAIAAgeIAaAAIAAgUIAfAAIAAAUIAoAAIgCgaIgRAHIgDgKIg/AHIgIgaQASgPAQgXIgeADIgHgVQAXgZARglIAXAJQgFAMgKAPIgQAXIAUgCIANgXIAXALIgBgyIAfAAQAABtAKA+IAdAAIgJgTIAagGQAJAQACAJIAcAAIAAAeIhQAAIAJAhQAVgQANgQIAWARQgYAbgUAPQAEAKAGAEQAFAEAFAAQAEAAADgEQACgEADgLIAFgdIAXAKIgEAgQgFAVgIAKQgIAJgNAAQgaAAgVgjQgdASgkAPIgOgbQAigNAggUQgIgVgGgdIgvAAIgCAOIAsAZIgOAaQgLgJgXgNQgFASgLASQgIARgRAUgAAdgbQgDgngBgqQgLATgPAUIgcAiIAegDIgIgVIATgJIARApIAAAAgAh2CbIAAiEQgKAfgNAYIgLgsQALgWAHgUQAIgWAIggIgdAAIAAgiIAdAAIAAg7IAgAAIAAA7IAVAAIAAAiIgVAAIAAAeQASARAKAMIgPAbIgNgPIAACSgACAgUIg8AGIgIgYQASgRAQgVIgdADIgIgXQAKgKAKgSQAKgQAGgQIAYAJQgFALgJAQQgIAOgIAJIAWgBIAOgbIAXALQgLAUgOAUQgQAVgMAOIAcgDIgIgUIAUgIIALAbIAJAcIgWAIg");
	this.shape_99.setTransform(240.85,86.45);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AhLCWIgIgmIAuAAQAMAAADgBQAEgCABgDQACgEAAgJIAAgiIiHAAIAAgkICHAAIAAgpIhwAAIAAglIBwAAIAAgtQhAAFgxABIgCgkQAsgBBSgGQBRgGAugGIAGAlQgmAEhDAFIAAAwIBoAAIAAAlIhoAAIAAApIB/AAIAAAkIh/AAIAAAwQAAARgEAJQgFAJgKAEQgIAEgUAAg");
	this.shape_100.setTransform(207.8,86.625);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AhACJIALgRIguAAIAAAUIgdAAIAAhxIgRAaIgIgsQAPgVALgbQALgbAHggIgkAAIAAgiIBsAAIAAAiIgoAAQgHAigJAWIAuAAIAACWQALgTAEgSQAFgTABgWIABiVIBHAAIAAgkIAjAAIAAAkIBFAAIAAAiIgNAkIgggHIAKgdIgiAAIAAA1IA0AAIAAAhQgLAfgHAPQgIARgPAUQAVASApARIgQAiQgVgLgTgLQgOgIgPgNQgYAWgqAXIgSggQAmgSAXgVQgLgNgKgVQgJgWgIgYQAAAggEAXQgDAUgIAZQgJAWgSAegAhjBWIAZAAIAAhgIgZAAgABFA8QAJgMAHgOQAIgSAEgOIg3AAQAMAkAPAWgAAJggIAlAAIAAg1IglAAg");
	this.shape_101.setTransform(174.6,86.6);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AiXB8QA3gOAdgSQAegTAJgZIh2AAIAAgiIB7AAIAAgpIAmAAIAAApIAuAAIgXgXIAUgVQAQANATAUIgLALIBBAAIAAAiIiDAAQAPAZAhARQAgATA4AMIgQAkQg2gOgggTQghgTgSgaQgRAagfASQgfAUg0AQgAiRgfIA8gYQAegNAXgMIAPAeQhGAjgsAPgAAPgzIAOgdIB1AyIgNAdgABng7IAAggIjNAAIAAAgIgmAAIAAhBIB9AAIgLgcIAogFQAGAMAIAVIBxAAIAABBg");
	this.shape_102.setTransform(141.4,86.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.instance_6}]},150).to({state:[]},75).wait(100));

	// bg
	this.instance_7 = new lib.ClipGroup_21();
	this.instance_7.setTransform(741.15,149.05,1,1,0,0,0,231,195.3);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(150).to({_off:false},0).to({_off:true},75).wait(100));

	// animate
	this.instance_8 = new lib.Symbol7();
	this.instance_8.setTransform(291.65,160.15,1,1,0,0,0,135.1,37.4);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(225).to({_off:false},0).wait(100));

	// gift1
	this.instance_9 = new lib.Symbol8();
	this.instance_9.setTransform(558.25,122.55,1,1,0,0,0,65.8,68.2);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(225).to({_off:false},0).wait(1).to({regX:60.7,regY:77,x:553.15,y:131.35},0).wait(4).to({alpha:0.0667},0).wait(1).to({alpha:0.1333},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.2667},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.4667},0).wait(1).to({alpha:0.5333},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.7333},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.8667},0).wait(1).to({alpha:0.9333},0).wait(1).to({alpha:1},0).wait(81));

	// gift2
	this.instance_10 = new lib.Symbol9();
	this.instance_10.setTransform(708.2,109.95,1,1,0,0,0,63.3,80.7);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(225).to({_off:false},0).wait(1).to({regX:60.7,regY:90.1,x:705.6,y:119.35},0).wait(14).to({alpha:0.0667},0).wait(1).to({alpha:0.1333},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.2667},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.4667},0).wait(1).to({alpha:0.5333},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.7333},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.8667},0).wait(1).to({alpha:0.9333},0).wait(1).to({alpha:1},0).wait(71));

	// gift3
	this.instance_11 = new lib.Symbol10();
	this.instance_11.setTransform(858,115.05,1,1,0,0,0,60.6,60.7);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(225).to({_off:false},0).wait(1).to({regX:60.7,x:858.1},0).wait(24).to({alpha:0.0667},0).wait(1).to({alpha:0.1333},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.2667},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.4667},0).wait(1).to({alpha:0.5333},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.7333},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.8667},0).wait(1).to({alpha:0.9333},0).wait(1).to({alpha:1},0).wait(61));

	// bg
	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#030000").s().p("AADBFQgVgVAAgvQAAgtAVgVQATgTAvAAQAwAAATATQAVAVAAAtQAAAvgWAVQgTATgvAAQguAAgUgTgAAfgnQgJALAAAdQAAAfAJALQALAMAbAAQAcAAAKgMQAGgHACgLQACgIAAgQQAAgPgCgHQgCgLgGgHQgKgMgcAAQgbAAgLAMgAjOBIQgQgLgCgYQgCgOAFgOQAEgMASgKQAPgIAmgBQARgBAcACQAAgOgEgGQgFgHgPgDQgNgCgRACQgXACgaAJQgBAAAAAAQgBABAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBIAAgbQAAgFADgBQAZgJAigCQA3gCAWAeQANASAAAgIAAAhQgCAXgHAMQgHAMgMAGQgRAKghABIgIAAQgpAAgVgQgAiPAJQghABgHAKQgDADAAAKQABALAJAGQALAFAegBQAagBAFgLQAEgHAAgYQgYgCgOAAIgFAAgAH+BVQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAigQAAgBAAgBQAAAAABgBQAAAAABAAQAAAAABAAIAkAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAABIAACgQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAgAGdBVQgBAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAhUQAAghgDgFQgFgKgVAAQgRAAgGACQgGACgDAIIgBAKIAABuQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAIgjAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAhuQAAgHgCgDQgCgHgGgDQgGgCgSAAQgUAAgFAKQgDAFAAAhIAABUQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAIgjAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAhnQAAgVADgKQADgLAIgIQAPgNApAAQAgAAATAKIAHAAQASgKAfAAQAoAAAQAPQAJAJADANQACAJAAAYIAABgQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAgAk5BVQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAigQAAgBAAgBQAAAAAAgBQABAAAAAAQAAAAABAAIAkAAQAAAAABAAQAAAAABAAQAAABAAAAQABABAAABIAACgQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAgAmaBVQgBAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgog3IgrA3QAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAIgtAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIABgDIBAhPIhAhPIAAgDQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIAtAAQABAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIApA3IAqg3QAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIAuAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIAAADIg/BNIA/BRIAAADQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAg");
	this.shape_103.setTransform(237.6417,63.4905);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AAIBTIAAgpIhHAAIAAgTIBMhpIAaAAIAABkIAYAAIAAAYIgYAAIAAApgAggASIAoAAIAAg5g");
	this.shape_104.setTransform(321.9,63.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AAFBTIAAiDIgoAWIAAgcIAygcIAVAAIAAClg");
	this.shape_105.setTransform(307.325,63.6);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgoA4IAAgcQARALASAAQAHAAAGgDQAEgEAAgGQAAgHgbgLQgcgJAAgYQAAgRANgKQANgLATAAQARAAASAHIAAAbQgPgJgRAAQgHAAgFAEQgEADAAAFQAAAHAbAKQAcAKAAAZQAAAQgOALQgMALgVAAQgSAAgTgIg");
	this.shape_106.setTransform(399.55,65.9);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgmAuQgSgTAAgbQAAgcARgRQARgSAZAAQAYAAAPARQAPARAAAbIgBALIhRAAQABAOAKAIQAKAIAPAAQARABATgLIAAAaQgWAJgTAAQgbAAgRgSgAgQgfQgIAIgBAMIA0AAQAAgMgHgIQgHgIgLAAQgKAAgIAIg");
	this.shape_107.setTransform(387.525,65.9);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgPBXIAAh5IAeAAIAAB5gAgMg3QgFgFAAgIQAAgIAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAIQAAAIgFAFQgFAFgIAAQgHAAgFgFg");
	this.shape_108.setTransform(377.725,63.325);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgjA/IAAh6IAgAAIAAANQAMgQARAAIAKACIAAAbIgLgBQgQAAgMAQIAABRg");
	this.shape_109.setTransform(370.225,65.75);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgnAuQgRgTAAgbQAAgcARgRQARgSAZAAQAYAAAPARQAPARAAAbIgBALIhRAAQABAOAKAIQAKAIAPAAQAQABAUgLIAAAaQgWAJgUAAQgaAAgSgSgAgQgfQgIAIgBAMIA0AAQgBgMgGgIQgIgIgKAAQgKAAgIAIg");
	this.shape_110.setTransform(358.5,65.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("Ag1BLIAAgdQAZAPAWAAQAOAAAIgHQAJgGAAgLQAAgOgogPQgogNAAggQAAgWAQgNQAQgOAaAAQAXAAAWAJIAAAdQgVgMgVAAQgNAAgJAGQgIAGAAAKQAAAOAoAOQAoAOAAAhQABAWgSAOQgRAOgZAAQgYAAgagMg");
	this.shape_111.setTransform(345.2,63.625);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgHAAQAAgEAHgBQAIABAAAEQAAAFgIABQgHgBAAgFg");
	this.shape_112.setTransform(421.425,86.45);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgnAkIgWgGQgHAGgMAAQgGAAgEgCQgFgDAAgFQAAgIANAAQAHAAAGACQAGgPACgHQgHgBgEgCIABgEIAKACIABAAQAHgkAVABQAFAAADADQAEAEAAAEQAAANgNAJIgNAHQgFAOgEAIIgBADIATAGQAZAGAWAAQA4ABAdgKIABAEQgoANgvAAQgWAAgagHgAhZAbIACACQAAABABAAQAAAAABAAQAAABABAAQAAAAABAAQAFgBAFgEQgEgCgGAAQgGAAAAADgAgqgWQgCAHgBAHQARgEACgSQAAgGgFAAQgGAAgFAOg");
	this.shape_113.setTransform(420.4477,88.1236);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgbAMIgCgDQgLAHgKAAQgSAAAAgNQAAgGAGgFQAHgGAJAAQAOAAAAAIQAAAJgSABIgEAAIAAABQAAAFAHgBQALAAAHgGIAGgQIANAAIgFASQAAABAAAAQAAABABAAQAAAAABABQAAAAABAAQADAAACgCIACgCIABgCQAAgFAEgGQAGgFAJAAQAGAAADACIgCAGQgCgDgEAAQgDAAgCAFQgDAEAAACQAAAHAGAAQAFAAAFgGIAAgCQAAgEAGgFQAFgHAJAAQAGAAACAEIABgCIANgBIgGATQAAAAABABQAAAAAAABQAAAAABAAQAAAAABAAIAFgCIABAFQgFAFgIAAQgEAAgCgCIgCgDQgEAFgIAAQgFAAgEgDIgCgEQgHAHgJAAQgGAAgDgDIgDgDQgHAHgJAAQgGAAgCgEgAAogEQgCAEAAAEQAAAFAEAAQAHAAACgPQAAgEgEAAQgFAAgCAGgAgzgFIgCAFQALABABgIQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAgBAAIAAAAQgEAAgCAFg");
	this.shape_114.setTransform(422.9,88.975);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FF2A0C").s().p("AhOBPQgiggAAgvQAAguAiggQAhghAtAAQAuAAAhAhQAiAgAAAuQAAAvgiAgQghAhguAAQgtAAghghg");
	this.shape_115.setTransform(420.75,88.875);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#030000").s().p("AAMAcIAAgaIgXAAIAAAaIgJAAIAAg3IAJAAIAAAXIAXAAIAAgXIAJAAIAAA3g");
	this.shape_116.setTransform(401.925,88.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#030000").s().p("AgDAcIAAgwIgPAAIAAgHIAlAAIAAAHIgPAAIAAAwg");
	this.shape_117.setTransform(396.35,88.825);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#030000").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_118.setTransform(392.375,88.825);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#030000").s().p("AAKAcIgKgnIgJAnIgKAAIgNg3IAIAAIALAtIAKgtIAHAAIAKAtIALgtIAIAAIgNA3g");
	this.shape_119.setTransform(387,88.85);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#030000").s().p("AgUAcIAAg3IAPAAQAKAAAGAFQAKAHAAAPQAAAOgIAIQgGAGgRAAgAgMAUIAFAAIAHAAQAKgDACgKIAAgHQAAgPgLgEIgKgBIgDAAg");
	this.shape_120.setTransform(377.125,88.825);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#030000").s().p("AgQAcIAAg3IAgAAIAAAHIgXAAIAAAQIAWAAIAAAHIgWAAIAAARIAYAAIAAAIg");
	this.shape_121.setTransform(371.5,88.825);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#030000").s().p("AAKAcIgMgXIgJAAIAAAXIgIAAIAAg3IAWAAQAJADADAFQACACAAAHQAAAFgDAEIgEADIgEACIAOAYgAgLgBIAJAAQAKAAAAgKQAAgFgEgCQgDgCgIAAIgEAAg");
	this.shape_122.setTransform(366.2,88.825);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#030000").s().p("AgQAcIAAg3IAgAAIAAAHIgXAAIAAAQIAVAAIAAAHIgVAAIAAARIAYAAIAAAIg");
	this.shape_123.setTransform(360.75,88.825);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#030000").s().p("AgQAcIAAg3IAgAAIAAAHIgXAAIAAAQIAVAAIAAAHIgVAAIAAARIAYAAIAAAIg");
	this.shape_124.setTransform(355.575,88.825);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#030000").s().p("AAMAcIgXgqIAAAqIgJAAIAAg3IAKAAIAXAqIAAgqIAIAAIAAA3g");
	this.shape_125.setTransform(349.6,88.825);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#030000").s().p("AgDAcIAAg3IAHAAIAAA3g");
	this.shape_126.setTransform(344.875,88.825);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#030000").s().p("AgPAVQgGgIAAgNQAAgRAMgIQAFgDAGAAQANAAAEAJQACADAAAGIgHAAQgCgIgFgCIgFgBQgGAAgEAGQgEAGAAAJQAAAVAOAAQAHAAAGgDIAAgMIgMAAIAAgGIAUAAIAAAXIgFACQgIAEgIAAQgKAAgHgIg");
	this.shape_127.setTransform(340.25,88.825);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#030000").s().p("AAMAcIgXgqIAAAqIgJAAIAAg3IAKAAIAXAqIAAgqIAIAAIAAA3g");
	this.shape_128.setTransform(334.05,88.825);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#030000").s().p("AgQAcIAAg3IAgAAIAAAHIgXAAIAAAQIAVAAIAAAHIgVAAIAAARIAYAAIAAAIg");
	this.shape_129.setTransform(328.5,88.825);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#030000").s().p("AgKAaQgNgIAAgSQABgRAKgHQAGgEAGAAQALAAAFAGQAIAIAAAOQAAASgLAHQgGAEgHAAQgGAAgEgDgAgGgTQgFADgCAJIgBAHQAAAIADAFIADAFQAEADAEAAQAIAAAEgHQADgGAAgIQAAgLgGgGQgFgEgEAAQgCAAgEACg");
	this.shape_130.setTransform(319.525,88.825);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#030000").s().p("AgHAbQgOgIAAgTQAAgPAKgIQAGgFAHAAQAMAAAGAKIABAIIgIAAIgBgFQgEgFgGAAQgFAAgEADQgEAHgBAKQABANAFAFQAEADAEAAQAEAAADgCQAFgEAAgHIAIAAQAAAIgEAFQgFAIgLAAQgEAAgFgCg");
	this.shape_131.setTransform(313.5,88.825);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#030000").s().p("AgKADIAAgFIAVAAIAAAFg");
	this.shape_132.setTransform(324.2,89.5);

	this.instance_12 = new lib.Group();
	this.instance_12.setTransform(187.15,231.4,1,1,0,0,0,154.8,4.7);
	this.instance_12.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103}]},225).wait(100));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(481.7,67.8,491.59999999999997,295.7);
// library properties:
lib.properties = {
	id: 'BEB13B6B44DE43E0A9E4E5B0A247ECCF',
	width: 970,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/970x250_200k_atlas_1.jpg", id:"970x250_200k_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BEB13B6B44DE43E0A9E4E5B0A247ECCF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;